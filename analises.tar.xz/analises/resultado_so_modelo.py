# LAY-over nos jogos em que SÓ O MODELO disparou o gatilho completo (v7, liga nunca vista, 20/21 a 24/25)
# Odd Pinnacle de fechamento do over 2,5 (football-data) + spread 2,2%, comissão 6,5%; ganha com até 2 gols.
# Sem os jogos em que o time que disparou teve 2+ vermelhos na janela, como na estratégia.
import sys, glob, gzip, json, os; sys.path.insert(0, "modelo_xg"); sys.path.insert(0, "src")
import numpy as np, pandas as pd
import treina_avalia as t
import betedges.leagues as L
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
FD = {"Serie_A": "data/historical/serie-a-all/*.csv", "La_liga": "data/historical/la-liga/*.csv"}
PASTA = {"Serie_A": "serie_a", "La_liga": "la_liga"}

def serie(j, col, liga):
    w, lim = t.LAY_OVER[liga]
    sofr = j.rename(columns={"time": "adversario", "adversario": "time", col: "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
    x = j[["f_arq", "data", "time", col, "gols"]].rename(columns={col: "xg"}).merge(sofr, on=["f_arq", "time"]).sort_values("data")
    g = x.groupby("time"); ant = lambda s, n: s.rolling(n).mean().shift(1)
    xga_w, gs_w = g.xga.transform(lambda s: ant(s, w)), g.gs.transform(lambda s: ant(s, w))
    xg4, gl4 = g.xg.transform(lambda s: ant(s, 4)), g.gols.transform(lambda s: ant(s, 4))
    x["defesa"] = (gs_w - xga_w) / xga_w >= lim
    x["ataque"] = ((xg4 - gl4) / xg4 >= 0.35) & (xg4 > gl4)
    x["ok"] = xga_w.notna() & xg4.notna()
    return x

linhas = []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    w = t.LAY_OVER[b][0]
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    U, M = serie(j, "xg_u", b), serie(j, "xg_soma", b)
    ku = U.groupby("f_arq").agg(d=("defesa", "any"), a=("ataque", "any"), ok=("ok", "all"))
    km = M.groupby("f_arq").agg(d=("defesa", "any"), a=("ataque", "any"))
    k = ku.join(km, rsuffix="_m"); k = k[k.ok]
    k["u"], k["m"] = k.d & ~k.a, k.d_m & ~k.a_m
    k["grupo"] = np.select([k.u & k.m, ~k.u & k.m, k.u & ~k.m], ["os dois", "só modelo", "só Understat"], "nenhum")
    trig_m = M[M.defesa].groupby("f_arq").time.apply(set)          # times que dispararam a defesa no modelo
    trig_u = U[U.defesa].groupby("f_arq").time.apply(set)
    # football-data: odd, placar, vermelhos; vermelhos próprios na janela de cada time
    fd = pd.concat(pd.read_csv(f, usecols=["Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG", "HR", "AR", "PC>2.5"]).assign(arq=os.path.basename(f))
                   for f in sorted(glob.glob(FD[b])))
    fd["dia"] = pd.to_datetime(fd.Date, dayfirst=True)
    lados = pd.concat([fd.assign(time=fd.HomeTeam, verm=fd.HR), fd.assign(time=fd.AwayTeam, verm=fd.AR)]).sort_values("dia")
    lados["verm_janela"] = lados.groupby("time").verm.transform(lambda s: s.rolling(w).sum().shift(1))
    # casar jogos FotMob -> football-data pela data (Brasília) e placar, candidato único; ids FotMob -> nome football-data por voto
    info, votos = {}, {}
    for f in glob.glob(f"data/bruto/fotmob/{PASTA[b]}/202[0-4]/*.json.gz"):
        if f.endswith("liga.json.gz"): continue
        d = json.load(gzip.open(f)); g = d["general"]; h = d["header"]["teams"]
        dia = pd.Timestamp(g["matchTimeUTC"]).tz_convert("America/Sao_Paulo").tz_localize(None).normalize()
        cand = fd[(fd.FTHG == h[0]["score"]) & (fd.FTAG == h[1]["score"]) & ((fd.dia - dia).abs() <= pd.Timedelta(days=1))]
        info[os.path.basename(f)] = (g["homeTeam"]["id"], g["awayTeam"]["id"], cand)
        if len(cand) == 1:
            for fid, nome in ((g["homeTeam"]["id"], cand.HomeTeam.iloc[0]), (g["awayTeam"]["id"], cand.AwayTeam.iloc[0])):
                votos.setdefault(fid, {}).setdefault(nome, 0); votos[fid][nome] += 1
    nome = {fid: max(v, key=v.get) for fid, v in votos.items()}
    for f, r in k[k.grupo != "nenhum"].iterrows():
        hid, aid, cand = info[f]
        cand = cand[(cand.HomeTeam == nome.get(hid)) & (cand.AwayTeam == nome.get(aid))]
        if len(cand) != 1: continue
        jg = cand.iloc[0]
        trig = trig_m.get(f, set()) if r.grupo == "só modelo" else trig_u.get(f, set())
        verm = lados[(lados.dia == jg.dia) & lados.time.isin([nome.get(x) for x in trig])].verm_janela
        linhas.append(dict(liga=b, grupo=r.grupo, dia=jg.dia, odd=jg["PC>2.5"], gols=jg.FTHG + jg.FTAG,
                           verm2=bool((verm >= L.RED_CARD_LIMIAR).any())))
d = pd.DataFrame(linhas)
d["season"] = np.where(d.dia.dt.month >= 7, d.dia.dt.year, d.dia.dt.year - 1)
x = d[(d.season == 2021) & d.grupo.isin(["só modelo", "só Understat"])]
print("21/22 antes dos filtros:", x.groupby("grupo").size().to_dict(), "| sem odd:", x[x.odd.isna()].groupby("grupo").size().to_dict(),
      "| com 2+ vermelhos:", x[x.verm2].groupby("grupo").size().to_dict())
if "--so-contagem" in sys.argv: sys.exit()
d = d.dropna(subset=["odd"])
d = d[~d.verm2]
d["season"] = np.where(d.dia.dt.month >= 7, d.dia.dt.year, d.dia.dt.year - 1)
d["win"] = d.gols <= 2
lay = d.odd * (1 + L.SPREAD_OVER_UNDER)
d["r"] = np.where(d.win, (1 / (lay - 1)) * (1 - L.COMMISSION), -1.0)      # por unidade de responsabilidade
d["stake"] = 1 / (lay - 1)
def resumo(x):
    se = x.r.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else np.nan
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.1%}",
                          ic95=f"{x.r.mean()-1.96*se:+.1%} a {x.r.mean()+1.96*se:+.1%}", yield_=f"{x.r.sum()/x.stake.sum():+.1%}"))
print("LAY-over por grupo (ROI sobre a responsabilidade; yield sobre o valor casado)\n")
print(d.groupby(["grupo"]).apply(resumo).to_string())
for gr in ("só modelo", "só Understat"):
    print(f"\n{gr}, por liga:"); print(d[d.grupo == gr].groupby("liga").apply(resumo).to_string())
    print(f"\n{gr}, por temporada:"); print(d[d.grupo == gr].groupby("season").apply(resumo).to_string())
