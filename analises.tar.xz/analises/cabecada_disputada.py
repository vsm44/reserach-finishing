# Cabeçadas na Understat por último lance (Aerial = disputada?): quanto valem, quanto são marcadas como grande chance
# no FotMob e quanto o nosso modelo erra nelas
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl").dropna(subset=["xg_understat"])
p = pd.read_pickle("modelo_xg/dados/chutes_pareados.pkl")[["f_arq", "f_id", "u_lastAction"]]
c = c.merge(p, on=["f_arq", "f_id"], how="left")
# previsão fora da liga (v7), para medir o erro
partes = []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")]
    m = t.treina(base, t.V7)
    te = c[(c.liga == b) & (c.lance != "Penalty")].copy(); te["nosso"] = t.preve(m, te, t.V7, 0.75)
    partes.append(te)
x = pd.concat(partes)
cab = x[x.parte == "Header"].copy()
cab["dist"] = pd.cut(cab.distancia, [0, 6, 9, 12, 30])
top = cab.u_lastAction.value_counts().head(6).index
g = cab[cab.u_lastAction.isin(top)].groupby(["u_lastAction", "dist"], observed=True).agg(
    cabecadas=("gol", "size"), gol=("gol", "mean"), xg_understat=("xg_understat", "mean"), nosso=("nosso", "mean"),
    marcada_gc=("gc_marcada", "mean"))
g["erro_medio"] = g.nosso - g.xg_understat
print("cabeçadas por último lance (Understat) e distância:")
print(g.round(3).to_string())
print("\nparcela de cada último lance entre as cabeçadas:", (cab.u_lastAction.value_counts(normalize=True).head(8) * 100).round(1).to_dict())
