# "Dá resultado parecido?" — roda o LAY-over duas vezes nos mesmos jogos (La Liga e Serie A, 20/21 a 24/25):
# uma com o xG da Understat e outra com o do nosso modelo (v7, liga nunca vista). Compara o dinheiro.
# Odd Pinnacle de fechamento do over 2,5 + spread 2,2%, comissão 6,5%, sem os jogos com 2+ vermelhos na janela.
import sys, glob, gzip, json, os; sys.path.insert(0, "modelo_xg"); sys.path.insert(0, "src")
import numpy as np, pandas as pd
import treina_avalia as t
import betedges.leagues as L
rng = np.random.default_rng(7)
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
FD = {"Serie_A": "data/historical/serie-a-all/*.csv", "La_liga": "data/historical/la-liga/*.csv"}
PASTA = {"Serie_A": "serie_a", "La_liga": "la_liga"}

linhas = []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    w = t.LAY_OVER[b][0]
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    gu, gm = t.gatilhos(j, "xg_u", b), t.gatilhos(j, "xg_soma", b)
    gu, gm = gu.align(gm, join="inner")
    # times que dispararam a defesa em cada régua, para o filtro de vermelhos
    def disparou(col):
        s = j.rename(columns={"time": "adversario", "adversario": "time", col: "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
        x = j[["f_arq", "data", "time"]].merge(s, on=["f_arq", "time"]).sort_values("data")
        g = x.groupby("time"); ant = lambda s_, n: s_.rolling(n).mean().shift(1)
        x["gap"] = (g.gs.transform(lambda s_: ant(s_, w)) - g.xga.transform(lambda s_: ant(s_, w))) / g.xga.transform(lambda s_: ant(s_, w))
        return x[x.gap >= t.LAY_OVER[b][1]].groupby("f_arq").time.apply(set)
    tu, tm = disparou("xg_u"), disparou("xg_soma")
    # football-data: odd, placar e vermelhos na janela
    fd = pd.concat(pd.read_csv(f, usecols=["Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG", "HR", "AR", "PC>2.5"]) for f in sorted(glob.glob(FD[b])))
    fd["dia"] = pd.to_datetime(fd.Date, dayfirst=True)
    lados = pd.concat([fd.assign(time=fd.HomeTeam, verm=fd.HR), fd.assign(time=fd.AwayTeam, verm=fd.AR)]).sort_values("dia")
    lados["verm_janela"] = lados.groupby("time").verm.transform(lambda s_: s_.rolling(w).sum().shift(1))
    info, votos = {}, {}
    for f in glob.glob(f"data/bruto/fotmob/{PASTA[b]}/202[0-4]/*.json.gz"):
        if f.endswith("liga.json.gz"): continue
        d = json.load(gzip.open(f)); g = d["general"]; h = d["header"]["teams"]
        dia = pd.Timestamp(g["matchTimeUTC"]).tz_convert("America/Sao_Paulo").tz_localize(None).normalize()
        cand = fd[(fd.FTHG == h[0]["score"]) & (fd.FTAG == h[1]["score"]) & ((fd.dia - dia).abs() <= pd.Timedelta(days=1))]
        info[os.path.basename(f)] = (g["homeTeam"]["id"], g["awayTeam"]["id"], cand)
        if len(cand) == 1:
            for fid, nome in ((g["homeTeam"]["id"], cand.HomeTeam.iloc[0]), (g["awayTeam"]["id"], cand.AwayTeam.iloc[0])):
                votos.setdefault(fid, {}).setdefault(nome, 0); votos[fid][nome] += 1
    nome = {fid: max(v, key=v.get) for fid, v in votos.items()}
    for f in gu.index:
        hid, aid, cand = info[f]
        cand = cand[(cand.HomeTeam == nome.get(hid)) & (cand.AwayTeam == nome.get(aid))]
        if len(cand) != 1: continue
        jg = cand.iloc[0]
        for regua, gat, trig in (("Understat", gu, tu), ("Nosso", gm, tm)):
            if not gat.loc[f, "LAY-over completo"]: continue
            verm = lados[(lados.dia == jg.dia) & lados.time.isin([nome.get(x) for x in trig.get(f, set())])].verm_janela
            if (verm >= L.RED_CARD_LIMIAR).any(): continue
            linhas.append(dict(liga=b, regua=regua, f_arq=f, dia=jg.dia, odd=jg["PC>2.5"], gols=jg.FTHG + jg.FTAG))
d = pd.DataFrame(linhas).dropna(subset=["odd"])
d["season"] = np.where(d.dia.dt.month >= 7, d.dia.dt.year, d.dia.dt.year - 1)
d["win"] = d.gols <= 2
lay = d.odd * (1 + L.SPREAD_OVER_UNDER)
d["r"] = np.where(d.win, (1 / (lay - 1)) * (1 - L.COMMISSION), -1.0)
d["stake"] = 1 / (lay - 1)

def resumo(x):
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}", yield_=f"{x.r.sum()/x.stake.sum():+.2%}"))
print("LAY-over com cada régua (mesmos jogos disponíveis, mesmas odds)\n")
print(d.groupby("regua").apply(resumo).to_string())
print("\npor temporada:"); print(d.groupby(["season", "regua"]).apply(resumo).unstack("regua").to_string())
print("\npor liga:"); print(d.groupby(["liga", "regua"]).apply(resumo).unstack("regua").to_string())
# quanto as duas se sobrepõem
su, sm = set(d[d.regua == "Understat"].f_arq), set(d[d.regua == "Nosso"].f_arq)
print(f"\njogos: só Understat {len(su - sm)}, só Nosso {len(sm - su)}, os dois {len(su & sm)}")
# diferença de ROI: sorteia rodadas inteiras (semanas) para dar o intervalo
d["semana"] = d.dia.dt.to_period("W")
sem = d.semana.unique()
difs = []
for _ in range(2000):
    esc = rng.choice(sem, len(sem), replace=True)
    x = pd.concat([d[d.semana == s] for s in esc])
    a, b_ = x[x.regua == "Nosso"], x[x.regua == "Understat"]
    if len(a) and len(b_): difs.append(a.r.mean() - b_.r.mean())
difs = np.array(difs)
print(f"\ndiferença de ROI (Nosso − Understat): {d[d.regua=='Nosso'].r.mean() - d[d.regua=='Understat'].r.mean():+.2%}")
print(f"  intervalo 95% por sorteio de semanas: {np.percentile(difs, 2.5):+.2%} a {np.percentile(difs, 97.5):+.2%}")
print(f"  chance de o nosso ficar dentro de 2 pontos do Understat: {np.mean(np.abs(difs) <= 0.02):.0%}")
print(f"  chance de o nosso ser pior: {np.mean(difs < 0):.0%}")
