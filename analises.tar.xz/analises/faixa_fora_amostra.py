# A faixa de finalização do adversário (xGOT sofrido - xGA) se sustenta fora dos anos em que foi achada?
# Escolhe a faixa só com 20/21 a 22/23 e confere em 23/24, 24/25 e 25/26. Sem olhar o futuro na escolha.
import sys; sys.path.insert(0, "modelo_xg/analises"); sys.path.insert(0, "src")
import numpy as np, pandas as pd
import betedges.leagues as L
import gatilho_xgot as G   # reaproveita a montagem das apostas com as duas partes
d = G.d.copy()
antigo, novo = d[d.season <= 2022], d[d.season >= 2023]
faixas = [(-9, -0.1), (-0.1, 0.1), (0.1, 0.3), (0.3, 0.5), (0.5, 9)]
def resumo(x):
    ep = x.r.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else np.nan
    return dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}",
                ic95=f"{x.r.mean() - 1.96*ep:+.1%} a {x.r.mean() + 1.96*ep:+.1%}", lucro_120=f"{x.r.sum()*120:,.0f}")
linhas = []
for lo, hi in faixas:
    for nome, x in (("20/21 a 22/23 (escolha)", antigo), ("23/24 a 25/26 (conferência)", novo)):
        s = x[(x.fin_gols > lo) & (x.fin_gols <= hi)]
        if len(s): linhas.append(dict(faixa=f"{lo} a {hi}", periodo=nome, **resumo(s)))
print("faixa de (xGOT sofrido - xGA) em gols, nos jogos anteriores\n")
print(pd.DataFrame(linhas).pivot(index="faixa", columns="periodo").to_string())
# a melhor faixa dos anos antigos, conferida ano a ano nos seguintes
melhor = max(faixas, key=lambda f: antigo[(antigo.fin_gols > f[0]) & (antigo.fin_gols <= f[1])].r.mean()
             if len(antigo[(antigo.fin_gols > f[0]) & (antigo.fin_gols <= f[1])]) > 30 else -9)
print(f"\nmelhor faixa em 20/21-22/23: {melhor[0]} a {melhor[1]}")
sel = d[(d.fin_gols > melhor[0]) & (d.fin_gols <= melhor[1])]
print("\nessa faixa, ano a ano:")
print(pd.DataFrame({int(s): resumo(x) for s, x in sel.groupby("season")}).T.to_string())
print("\nfora dessa faixa, ano a ano:")
fora = d[~d.index.isin(sel.index)]
print(pd.DataFrame({int(s): resumo(x) for s, x in fora.groupby("season")}).T.to_string())
print("\nresumo da conferência (23/24 em diante):")
print(pd.DataFrame({"dentro da faixa": resumo(sel[sel.season >= 2023]), "fora da faixa": resumo(fora[fora.season >= 2023])}).T.to_string())
