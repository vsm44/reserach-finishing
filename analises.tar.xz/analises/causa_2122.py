# 21/22: nos jogos discordantes do LAY-over completo, a discordância veio da defesa ou da exclusão de ataque?
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
def serie(j, col, liga):
    w, lim = t.LAY_OVER[liga]
    sofr = j.rename(columns={"time": "adversario", "adversario": "time", col: "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
    x = j[["f_arq", "data", "season", "time", col, "gols"]].rename(columns={col: "xg"}).merge(sofr, on=["f_arq", "time"]).sort_values("data")
    g = x.groupby("time"); ant = lambda s, n: s.rolling(n).mean().shift(1)
    xga_w, gs_w = g.xga.transform(lambda s: ant(s, w)), g.gs.transform(lambda s: ant(s, w))
    xg4, gl4 = g.xg.transform(lambda s: ant(s, 4)), g.gols.transform(lambda s: ant(s, 4))
    x["defesa"] = (gs_w - xga_w) / xga_w >= lim
    x["ataque"] = ((xg4 - gl4) / xg4 >= 0.35) & (xg4 > gl4)
    x["ok"] = xga_w.notna() & xg4.notna()
    return x
linhas = []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    U, M = serie(j, "xg_u", b), serie(j, "xg_soma", b)
    ku = U.groupby("f_arq").agg(d=("defesa", "any"), a=("ataque", "any"), ok=("ok", "all"), season=("season", "first"))
    km = M.groupby("f_arq").agg(d=("defesa", "any"), a=("ataque", "any"))
    k = ku.join(km, rsuffix="_m"); k = k[k.ok & (k.season == 2021)]
    k["u"], k["m"] = k.d & ~k.a, k.d_m & ~k.a_m
    for gr, sel in (("só Understat", k.u & ~k.m), ("só nosso", ~k.u & k.m)):
        x = k[sel]
        linhas.append(dict(liga=b, grupo=gr, jogos=len(x),
                           defesa_diferente=int((x.d != x.d_m).sum()),
                           mesma_defesa_mas_ataque_diferente=int(((x.d == x.d_m) & (x.a != x.a_m)).sum())))
r = pd.DataFrame(linhas); print(r.to_string(index=False)); print(r.groupby("grupo")[["jogos", "defesa_diferente", "mesma_defesa_mas_ataque_diferente"]].sum().to_string())
