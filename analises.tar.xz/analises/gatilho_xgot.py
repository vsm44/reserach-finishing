# O gatilho de defesa do LAY-over separado em duas partes, com xGOT (Opta):
#   (gols sofridos - xGA) = (xGOT sofrido - xGA) + (gols sofridos - xGOT sofrido)
#        gatilho de hoje      adversário finalizou bem     goleiro não pegou
# Tudo dividido pelo xGA da janela, para ficar na mesma escala do limiar. Só mede, não escolhe corte.
import sys, glob; sys.path.insert(0, "src")
import numpy as np, pandas as pd
import betedges.leagues as L
from betedges.cli import silencioso

xgot = pd.read_csv("modelo_xg/dados/xgot_por_jogo.csv")
xgot = xgot[(xgot.liga != "Portugal") & (xgot.temporada >= 2020)].copy()
xgot["data"] = pd.to_datetime(xgot.data)

def serie(liga, csv_glob, janela):
    # série por time e jogo, do lado do que ele SOFREU, casada com o football-data pelo calendário
    fd = pd.concat(pd.read_csv(f, usecols=["Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG"]) for f in sorted(glob.glob(csv_glob)))
    fd["dia"] = pd.to_datetime(fd.Date, dayfirst=True)
    x = xgot[xgot.liga == liga]
    votos = {}
    for j in x.itertuples():
        c = fd[(fd.FTHG == j.gols_mandante) & (fd.FTAG == j.gols_visitante) & ((fd.dia - j.data).abs() <= pd.Timedelta(days=1))]
        if len(c) == 1:
            for nf, nfd in ((j.mandante, c.HomeTeam.iloc[0]), (j.visitante, c.AwayTeam.iloc[0])):
                votos.setdefault(nf, {}).setdefault(nfd, 0); votos[nf][nfd] += 1
    mapa = {k: max(v, key=v.get) for k, v in votos.items()}
    linhas = []
    for lado, outro in (("mandante", "visitante"), ("visitante", "mandante")):
        linhas.append(pd.DataFrame(dict(date=x.data, team=x[lado].map(mapa),
                                        xga=x[f"xg_{outro}"], xgot_sofrido=x[f"xgot_{outro}"],
                                        gols_sofridos=x[f"gols_{outro}"])))
    s = pd.concat(linhas).dropna(subset=["team", "xgot_sofrido"]).sort_values("date")
    g = s.groupby("team")
    ant = lambda c: g[c].transform(lambda v: v.rolling(janela).mean().shift(1))
    xga_w, xgot_w, gs_w = ant("xga"), ant("xgot_sofrido"), ant("gols_sofridos")
    s["xga_janela"] = xga_w                                # nível do xGA na janela (o denominador)
    s["fin_gols"] = xgot_w - xga_w                         # a mesma diferença, em gols, sem dividir
    s["gol_gols"] = gs_w - xgot_w
    s["gap_opta"] = (gs_w - xga_w) / xga_w                 # o gatilho, com o xG da Opta
    s["parte_finalizacao"] = (xgot_w - xga_w) / xga_w      # o adversário finalizou acima das chances
    s["parte_goleiro"] = (gs_w - xgot_w) / xga_w           # o goleiro não pegou o que estava no alvo
    return s[["date", "team", "gap_opta", "parte_finalizacao", "parte_goleiro", "xga_janela", "fin_gols", "gol_gols"]].dropna()

linhas = []
for lg in L.LEAGUES.values():
    s = serie(lg.name, lg.csv_glob, lg.lay_over[0])
    with silencioso(True):
        b = L.build_league_bets(lg)
    over = b[(b.kind == "LAY-over") & (b.season >= 2020)].copy()
    over["date_n"] = pd.to_datetime(over.date).dt.normalize()
    for lado, col in (("home", "home"), ("away", "away")):
        over = over.merge(s.rename(columns={"team": col, "date": "date_n", "gap_opta": f"{col}_gap",
                                            "parte_finalizacao": f"{col}_fin", "parte_goleiro": f"{col}_gol",
                                            "xga_janela": f"{col}_xga", "fin_gols": f"{col}_fing", "gol_gols": f"{col}_golg"}),
                          on=["date_n", col], how="left")
    # o time que dispara é o de maior gap; as partes são as dele
    casa = (over.home_gap.fillna(-9) >= over.away_gap.fillna(-9))
    over["gap"] = np.where(casa, over.home_gap, over.away_gap)
    over["finalizacao"] = np.where(casa, over.home_fin, over.away_fin)
    over["goleiro"] = np.where(casa, over.home_gol, over.away_gol)
    over["xga_janela"] = np.where(casa, over.home_xga, over.away_xga)
    over["fin_gols"] = np.where(casa, over.home_fing, over.away_fing)
    over["gol_gols"] = np.where(casa, over.home_golg, over.away_golg)
    over["liga"] = lg.name
    linhas.append(over)
d = pd.concat(linhas, ignore_index=True).dropna(subset=["gap"])
d["r"] = L.ret(d)
def resumo(x):
    # intervalo de 95% do ROI: cada aposta é uma observação do retorno por unidade de risco
    ep = x.r.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else np.nan
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}",
                          ic95=f"{x.r.mean() - 1.96 * ep:+.1%} a {x.r.mean() + 1.96 * ep:+.1%}",
                          lucro_120=f"{x.r.sum() * 120:,.0f}"))
print(f"apostas do LAY-over com xGOT disponível: {len(d)}  |  total: {resumo(d).to_dict()}\n")
print("as duas partes do gatilho, em quintis (o time que disparou):")
for col, rot in (("finalizacao", "adversário finalizou acima das chances (xGOT sofrido - xGA)/xGA"),
                 ("goleiro", "goleiro não pegou (gols sofridos - xGOT sofrido)/xGA"),
                 ("gap", "gatilho inteiro, com xG da Opta")):
    print(f"\n{rot}")
    print(d.groupby(pd.qcut(d[col], 5, duplicates="drop"), observed=True).apply(resumo).to_string())
print("\nonde ficam os cortes e como os valores se distribuem:")
print(d[["finalizacao", "goleiro", "gap"]].describe(percentiles=[.1, .25, .5, .75, .9]).round(3).to_string())
print("\nfaixas fixas da finalização do adversário ((xGOT sofrido - xGA)/xGA):")
faixa_fin = pd.cut(d.finalizacao, [-9, -0.1, 0.1, 0.3, 0.5, 9])
print(d.groupby(faixa_fin, observed=True).apply(resumo).to_string())
print("\no que tem dentro de cada faixa da finalização (média):")
print(d.groupby(pd.cut(d.finalizacao, [-9, -0.1, 0.1, 0.3, 0.5, 9]), observed=True)[
    ["xga_janela", "fin_gols", "gol_gols", "gap"]].mean().round(3).to_string())
print("\nfaixas da MESMA diferença, mas em gols (xGOT sofrido - xGA), sem dividir:")
print(d.groupby(pd.cut(d.fin_gols, [-9, -0.1, 0.1, 0.3, 0.5, 9]), observed=True).apply(resumo).to_string())
print("\nfaixas fixas do goleiro ((gols sofridos - xGOT sofrido)/xGA):")
faixa_gol = pd.cut(d.goleiro, [-9, 0.2, 0.4, 0.6, 0.9, 9])
print(d.groupby(faixa_gol, observed=True).apply(resumo).to_string())
print("\nas duas faixas cruzadas (ROI e nº de apostas):")
cru = d.groupby([faixa_fin, faixa_gol], observed=True).apply(resumo)
print(cru.to_string())

print("\ncruzando as duas partes (acima ou abaixo da mediana de cada uma):")
d["fin_alta"] = d.finalizacao > d.finalizacao.median()
d["gol_alta"] = d.goleiro > d.goleiro.median()
print(d.groupby(["fin_alta", "gol_alta"]).apply(resumo).to_string())
# o grupo bom (adversário finalizou bem, goleiro não falhou) contra o resto, por liga e por temporada
d["grupo"] = np.where(d.fin_alta & ~d.gol_alta, "azar puro (bom)", "resto")
print("\npor liga:")
print(d.groupby(["liga", "grupo"]).apply(resumo).unstack("grupo").to_string())
print("\npor temporada:")
print(d.groupby(["season", "grupo"]).apply(resumo).unstack("grupo").to_string())
print("\npor liga e temporada (só o grupo bom):")
print(d[d.grupo == "azar puro (bom)"].groupby(["liga", "season"]).apply(resumo).unstack("season").to_string())
