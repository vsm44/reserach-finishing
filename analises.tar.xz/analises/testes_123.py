# Testes 1-3: a Understat muda o xG conforme pênalti, quem chuta, quem defende?
import sys
import numpy as np, pandas as pd
c = pd.read_pickle(sys.argv[1])
rng = np.random.default_rng(0)

print("== TESTE 1: pênaltis ==")
p = c[c.situation == "Penalty"]
print(f"pênaltis: {len(p)}  gols: {(p.result=='Goal').sum()} ({(p.result=='Goal').mean():.1%})")
print("xG distintos:", p.xG.round(4).nunique(), "| mais comuns:", p.xG.round(4).value_counts().head(5).to_dict())
print(p.groupby("season").xG.agg(["mean", "min", "max"]).round(4).to_string())

# Célula fina: mesmo lugar (distância e ângulo), mesmo tipo de lance, parte do corpo e último passe
q = c[c.situation != "Penalty"].copy()
dx, dy = (1 - q.X) * 105, (q.Y - 0.5) * 68
q["dist"] = np.hypot(dx, dy)
q["ang"] = np.degrees(np.abs(np.arctan2(dy, dx)))
q["cel"] = (pd.cut(q.dist, list(range(0, 21)) + list(range(22, 41, 2)) + [200]).astype(str) + "|"
            + pd.cut(q.ang, range(0, 95, 5), include_lowest=True).astype(str) + "|"
            + q.situation + "|" + q.shotType + "|" + q.lastAction)
g = q.groupby("cel").xG
q["n_cel"] = g.transform("size")
q = q[q.n_cel >= 5].copy()
q["res"] = q.xG - g.transform("mean")[q.index]
print(f"\nchutes sem pênalti em células com 5+ chutes: {len(q)} de {len(c[c.situation!='Penalty'])}")
print(f"quanto do xG a célula explica: {1 - q.res.var()/q.xG.var():.1%}  | desvio que sobra: {q.res.std():.4f}")

def metade(df, chave, minimo, rotulo):
    # Divide os chutes de cada grupo em duas metades sorteadas; se a Understat usa o grupo,
    # o desvio médio de uma metade prevê o da outra
    d = df[df.groupby(chave).res.transform("size") >= minimo].copy()
    d["lado"] = rng.integers(0, 2, len(d))
    m = d.groupby(chave + ["lado"]).res.mean().unstack().dropna()
    r = m[0].corr(m[1])
    # mesmo cálculo com o desvio embaralhado dentro das células (sem efeito de grupo)
    d["res_emb"] = d.groupby("cel").res.transform(lambda s: rng.permutation(s.values))
    me = d.groupby(chave + ["lado"]).res_emb.mean().unstack().dropna()
    print(f"{rotulo:<34} grupos {len(m):>5}  concordância entre metades {r:+.3f}  (embaralhado {me[0].corr(me[1]):+.3f})"
          f"  | desvio médio por grupo: dp {m.mean(axis=1).std():.4f}")

print("\n== TESTES 2 e 3: sobra algo depois do lugar e do tipo? ==")
metade(q, ["player_id"], 60, "quem chuta (60+ chutes)")
metade(q, ["time_chute", "season"], 1, "time que chuta, por temporada")
metade(q, ["time_defesa", "season"], 1, "time que defende, por temporada")
