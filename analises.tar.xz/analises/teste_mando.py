# A Understat dá xG diferente para chute do mandante? Mesma célula (lugar, tipo, parte, último passe),
# descontando o nível dos times na temporada e o placar do momento
import numpy as np, pandas as pd
c = pd.read_pickle("modelo_xg/dados/chutes_understat.pkl")
c["id_n"] = c.id.astype(int); c = c.sort_values(["match_id", "id_n"])
c["gol_h"] = ((c.result == "Goal") & (c.h_a == "h")) | ((c.result == "OwnGoal") & (c.h_a == "a"))
c["gol_a"] = ((c.result == "Goal") & (c.h_a == "a")) | ((c.result == "OwnGoal") & (c.h_a == "h"))
gm = c.groupby("match_id")
c["saldo"] = ((gm.gol_h.cumsum() - c.gol_h) - (gm.gol_a.cumsum() - c.gol_a)).where(c.h_a == "h",
             (gm.gol_a.cumsum() - c.gol_a) - (gm.gol_h.cumsum() - c.gol_h)).clip(-2, 2)
q = c[(c.situation != "Penalty") & (c.result != "OwnGoal")].copy()
dx, dy = (1 - q.X) * 105, (q.Y - 0.5) * 68
q["dist"], q["ang"] = np.hypot(dx, dy), np.degrees(np.abs(np.arctan2(dy, dx)))
q["cel"] = (pd.cut(q.dist, list(range(0, 21)) + list(range(22, 41, 2)) + [200]).astype(str) + "|"
            + pd.cut(q.ang, range(0, 95, 5), include_lowest=True).astype(str) + "|"
            + q.situation + "|" + q.shotType + "|" + q.lastAction + "|" + q.saldo.astype(str))
q = q[q.groupby("cel").xG.transform("size") >= 5].copy()
q["atk"] = q.time_chute + "|" + q.season.astype(str); q["dfn"] = q.time_defesa + "|" + q.season.astype(str)
r = q.xG - q.groupby("cel").xG.transform("mean")
q["res_cel"] = r
for _ in range(20):
    r = r - r.groupby(q.atk).transform("mean"); r = r - r.groupby(q.dfn).transform("mean")
q["res_times"] = r
print("desvio médio do xG, chute do MANDANTE menos chute do VISITANTE (mesma célula e placar):")
for col, rot in (("res_cel", "só célula"), ("res_times", "célula + nível dos times")):
    t = q.groupby(["liga", "season", "h_a"])[col].mean().unstack()
    t["casa - fora"] = t["h"] - t["a"]
    print(f"\n{rot}\n" + t["casa - fora"].round(4).unstack(0).to_string())
    tot = q.groupby("h_a")[col].mean()
    print(f"todas: casa - fora = {tot['h'] - tot['a']:+.4f}  | xG médio do chute {q.xG.mean():.3f}")
