# Qual grupo de variáveis fez a v4 subir? Só a prova da liga nunca vista (mais disparos)
import sys; sys.path.insert(0, "modelo_xg")
import pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
base = c[c.lance != "Penalty"].dropna(subset=["xg_understat"])
pen = c[c.lance == "Penalty"].dropna(subset=["xg_understat"]).groupby("liga").xg_understat.median()
LUGAR_GOL = ["gol_y", "gol_z"]
GRANDES = ["jg_grandes", "jg_grandes_perdidas", "jga_grandes"]
OUTRAS = ["jg_chutes_area", "jg_cruz", "jg_escanteios", "jga_chutes_area"]
versoes = {
    "v3": t.V3,
    "v3 + onde cruzou o gol": t.V3 + LUGAR_GOL,
    "v3 + grandes chances": t.V3 + GRANDES,
    "v3 + outras do jogo": t.V3 + OUTRAS,
    "v4 sem grandes chances": t.V3 + LUGAR_GOL + OUTRAS,
    "v4": t.V4,
}
linhas = []
for nome, cols in versoes.items():
    for liga_tr, liga_te in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
        m = t.treina(base[base.liga == liga_tr], cols)
        te = c[c.liga == liga_te].copy()
        te["xg_modelo"] = t.preve(m, te, cols, pen[liga_tr])
        r = t.mede(te, nome)[0]
        linhas.append(dict(versao=nome, testa=liga_te, corr_chute=r["corr_chute"], corr_jogo=r["corr_jogo"],
                           nivel=r["nivel_jogo"], dispersao=r["dispersao_jogo"], disparos_u=r["disparos_u"],
                           disparos_m=r["disparos_m"], concordancia=r["concordancia"]))
print(pd.DataFrame(linhas).to_string(index=False, float_format=lambda v: f"{v:.3f}"))
