# Concordância dos gatilhos por temporada (v7, liga nunca vista)
import sys; sys.path.insert(0, "modelo_xg")
import pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
linhas = []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    gu, gm = t.gatilhos(j, "xg_u", b), t.gatilhos(j, "xg_soma", b)
    gu, gm = gu.align(gm, join="inner")
    temp = j.groupby("f_arq").season.first()
    for s in sorted(temp.unique()):
        idx = temp[temp == s].index.intersection(gu.index)
        l = dict(liga=b, temporada=f"{s}/{s+1-2000}")
        for k in gu:
            u, mm = gu.loc[idx, k], gm.loc[idx, k]
            l[k] = f"{(u&mm).sum()/max((u|mm).sum(),1):.1%} ({int(u.sum())}/{int(mm.sum())})"
        linhas.append(l)
print(pd.DataFrame(linhas).to_string(index=False))

# Se a Understat mudou de modelo, o nível e a correlação do modelo contra ela mudariam de temporada para temporada
print()
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    for s, x in te.groupby("season"):
        j = t.tabela_jogo(x, "xg_modelo")
        print(f"{b:<8} {s}/{s+1-2000}  nível {j.xg_soma.mean()/j.xg_u.mean():.3f}  corr chute {x.xg_understat.corr(x.xg_modelo):.3f}  corr jogo {j.xg_u.corr(j.xg_soma):.3f}  xG Understat por chute {x.xg_understat.mean():.4f}")
