# Tabela de teste: xG da Opta, xGOT e gols de cada time em cada jogo, direto do cru do FotMob.
# Uma linha por jogo, com os dois lados. Serve para cruzar o xGOT com tudo; se não render nada, apagar.
# Uso: python pesquisa/clone_understat/analises/tabela_xgot.py [saida.csv]
import glob, gzip, json, os, sys
import pandas as pd

LIGAS = {"la_liga": "La Liga", "serie_a": "Serie A", "ligue_1": "Ligue 1", "portugal": "Portugal"}
SAIDA = sys.argv[1] if len(sys.argv) > 1 else "pesquisa/clone_understat/dados/xgot_por_jogo.csv"
CHAVES = {"expected_goals": "xg", "expected_goals_on_target": "xgot", "expected_goals_non_penalty": "xg_sem_penalti",
          "expected_goals_open_play": "xg_jogada", "expected_goals_set_play": "xg_bola_parada",
          "total_shots": "chutes", "ShotsOnTarget": "chutes_no_alvo", "big_chance": "grandes_chances",
          "big_chance_missed_title": "grandes_chances_perdidas"}


def numero(v):
    # "4 (15%)" -> 4; "1.88" -> 1.88; None -> None
    if v is None:
        return None
    if isinstance(v, str):
        v = v.split("(")[0].strip()
    try:
        return float(v)
    except ValueError:
        return None


linhas = []
for pasta, nome in LIGAS.items():
    for arq in sorted(glob.glob(f"data/bruto/fotmob/{pasta}/*/*.json.gz")):
        if arq.endswith("liga.json.gz"):
            continue
        with gzip.open(arq) as f:
            d = json.load(f)
        g, h = d["general"], d["header"]["teams"]
        # cada estatística vem como par [mandante, visitante]
        vals = {}
        for grp in ((d.get("content") or {}).get("stats") or {}).get("Periods", {}).get("All", {}).get("stats") or []:
            for s in grp.get("stats") or []:
                if s.get("key") in CHAVES and len(s.get("stats") or []) == 2 and s["stats"][0] is not None:
                    vals[CHAVES[s["key"]]] = [numero(v) for v in s["stats"]]
        dt = pd.Timestamp(g["matchTimeUTC"]).tz_convert("America/Sao_Paulo")
        linha = dict(liga=nome, temporada=arq.split("/")[-2], match_id=os.path.basename(arq).split(".")[0],
                     data=dt.strftime("%Y-%m-%d"), hora_brasilia=dt.strftime("%H:%M"),
                     mandante=g["homeTeam"]["name"], visitante=g["awayTeam"]["name"],
                     gols_mandante=h[0].get("score"), gols_visitante=h[1].get("score"))
        for col, par in vals.items():
            linha[f"{col}_mandante"], linha[f"{col}_visitante"] = par
        linhas.append(linha)
d = pd.DataFrame(linhas).sort_values(["liga", "data"])
os.makedirs(os.path.dirname(SAIDA), exist_ok=True)
d.to_csv(SAIDA, index=False)
print(f"{len(d)} jogos -> {SAIDA}")
print(d.groupby(["liga", "temporada"]).agg(jogos=("match_id", "size"), com_xgot=("xgot_mandante", lambda s: s.notna().mean())
                                           ).unstack("temporada").round(2).to_string())
