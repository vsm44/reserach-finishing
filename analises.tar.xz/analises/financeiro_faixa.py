# Financeiro (item 1) com a faixa de finalização do adversário (xGOT sofrido - xGA entre 0,3 e 0,5 gol):
# oficial; stake 3,3% só nas apostas da faixa; e LAY-over restrito à faixa.
import inspect, sys; sys.path.insert(0, "src"); sys.path.insert(0, "scripts"); sys.path.insert(0, "modelo_xg/analises")
import numpy as np, pandas as pd
import financeiro as F
import gatilho_xgot as G

d = F.carrega()
faixa = G.d[(G.d.fin_gols > 0.3) & (G.d.fin_gols <= 0.5)][["liga", "date", "home", "away"]].copy()
faixa["date"] = pd.to_datetime(faixa.date); faixa["na_faixa"] = True
d["date"] = pd.to_datetime(d.date)
d = d.merge(faixa, on=["liga", "date", "home", "away"], how="left")
d["na_faixa"] = (d.na_faixa.fillna(False)) & (d.kind == "LAY-over")
print(f"apostas na faixa: {int(d.na_faixa.sum())} de {len(d)}")

codigo = inspect.getsource(F.roda).replace("def roda(", "def roda_m(MULT, SO_FAIXA, ")
codigo = codigo.replace('''    d["rodada"] = d.date.map(lambda x: janela_da_rodada(x.date())[0])''',
'''    if SO_FAIXA:
        d = d[(d.kind != "LAY-over") | d.na_faixa]
    d["rodada"] = d.date.map(lambda x: janela_da_rodada(x.date())[0])''')
codigo = codigo.replace("        for b in grp.itertuples(index=False):\n",
                        "        for b in grp.itertuples(index=False):\n            m = MULT if b.na_faixa else 1.0\n")
for a, b in (("l = _lucro(risco, b)", "l = _lucro(risco * m, b)"), ('a["volume"] += _stake(risco, b)', 'a["volume"] += _stake(risco * m, b)'),
             ("risco=risco, stake=_stake(risco, b)", "risco=risco * m, stake=_stake(risco * m, b)"),
             ("stake_flat=_stake(100.0, b)", "stake_flat=_stake(100.0 * m, b)"), ("lucro_flat=_lucro(100.0, b)", "lucro_flat=_lucro(100.0 * m, b)")):
    codigo = codigo.replace(a, b)
exec(codigo, vars(F))
for nome, mult, so_faixa in (("OFICIAL (3% em tudo)", 1.0, False), ("3,3% nas apostas da faixa", 1.1, False),
                             ("LAY-over só na faixa (3%)", 1.0, True)):
    anos, r = F.roda_m(mult, so_faixa, d)
    det = r["detalhe"]
    print(f"\n== {nome} ==  drawdown {r['mdd']:.1%}")
    for a in anos.itertuples(index=False):
        sub = det[det.ano == a.ano]
        print(f"{a.ano}  {a.n:>4} apostas  volume {a.volume:>12,.0f}  lucro {a.lucro:>11,.0f}  yield {a.yld:>6.2%}  banca {a.banca_fim:>10,.0f}")
    print(f"TOTAL {r['n']:>4} apostas  volume {r['volume']:>12,.0f}  lucro {r['lucro']:>11,.0f}  yield {r['lucro']/r['volume']:>6.2%}  banca {r['banca_final']:>10,.0f}")
