# LAY-under com xGOT: o time que está devendo gol deve por finalizar mal ou porque o goleiro pegou?
#   (xG - gols) = (xG - xGOT) + (xGOT - gols)
#                  finalizou mal   goleiro pegou
# Mede dentro das apostas de LAY-under que já existem. Ganha quando o jogo passa de 1,5 gol.
import sys, glob; sys.path.insert(0, "src")
import numpy as np, pandas as pd
import betedges.leagues as L
from betedges.cli import silencioso

opta = pd.read_csv("modelo_xg/dados/xgot_por_jogo.csv")
opta = opta[(opta.liga != "Portugal") & (opta.temporada >= 2020)].copy()
opta["data"] = pd.to_datetime(opta.data)

def serie(liga, csv_glob, janela=3):
    fd = pd.concat(pd.read_csv(f, usecols=["Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG"]) for f in sorted(glob.glob(csv_glob)))
    fd["dia"] = pd.to_datetime(fd.Date, dayfirst=True)
    x = opta[opta.liga == liga]
    votos = {}
    for j in x.itertuples():
        c = fd[(fd.FTHG == j.gols_mandante) & (fd.FTAG == j.gols_visitante) & ((fd.dia - j.data).abs() <= pd.Timedelta(days=1))]
        if len(c) == 1:
            for nf, nfd in ((j.mandante, c.HomeTeam.iloc[0]), (j.visitante, c.AwayTeam.iloc[0])):
                votos.setdefault(nf, {}).setdefault(nfd, 0); votos[nf][nfd] += 1
    mapa = {k: max(v, key=v.get) for k, v in votos.items()}
    linhas = []
    for lado in ("mandante", "visitante"):
        linhas.append(pd.DataFrame(dict(date=x.data, team=x[lado].map(mapa), xg=x[f"xg_{lado}"],
                                        xgot=x[f"xgot_{lado}"], gols=x[f"gols_{lado}"])))
    s = pd.concat(linhas).dropna(subset=["team", "xgot"]).sort_values("date")
    g = s.groupby("team")
    ant = lambda c: g[c].transform(lambda v: v.rolling(janela).mean().shift(1))
    xg_w, xgot_w, gols_w = ant("xg"), ant("xgot"), ant("gols")
    s["gap_atq_opta"] = (xg_w - gols_w) / xg_w          # o gatilho do LAY-under, com xG da Opta
    s["finalizou_mal"] = (xg_w - xgot_w) / xg_w          # não acertou o alvo
    s["goleiro_pegou"] = (xgot_w - gols_w) / xg_w        # acertou o alvo e não fez
    s["fin_gols"] = xgot_w - xg_w                        # em gols, sem dividir
    s["gol_gols"] = gols_w - xgot_w
    return s[["date", "team", "gap_atq_opta", "finalizou_mal", "goleiro_pegou", "fin_gols", "gol_gols"]].dropna()

linhas = []
for lg in L.LEAGUES.values():
    if lg.name not in L.LAY_UNDER_LIGAS:
        continue
    s = serie(lg.name, lg.csv_glob)
    with silencioso(True):
        b = L.build_league_bets(lg)
    u = b[(b.kind == "LAY-under") & (b.season >= 2020)].copy()
    u["date_n"] = pd.to_datetime(u.date).dt.normalize()
    for col in ("home", "away"):
        u = u.merge(s.rename(columns={"team": col, "date": "date_n", "gap_atq_opta": f"{col}_gap",
                                      "finalizou_mal": f"{col}_fin", "goleiro_pegou": f"{col}_gol",
                                      "fin_gols": f"{col}_fing", "gol_gols": f"{col}_golg"}),
                    on=["date_n", col], how="left")
    casa = (u.home_gap.fillna(-9) >= u.away_gap.fillna(-9))    # o time gatilho é o de maior gap
    for novo, (a, bb) in {"gap": ("home_gap", "away_gap"), "finalizou_mal": ("home_fin", "away_fin"),
                          "goleiro_pegou": ("home_gol", "away_gol"), "fin_gols": ("home_fing", "away_fing"),
                          "gol_gols": ("home_golg", "away_golg")}.items():
        u[novo] = np.where(casa, u[a], u[bb])
    u["liga"] = lg.name
    linhas.append(u)
d = pd.concat(linhas, ignore_index=True).dropna(subset=["gap"])
d["r"] = L.ret(d)
def resumo(x):
    ep = x.r.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else np.nan
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}",
                          ic95=f"{x.r.mean()-1.96*ep:+.1%} a {x.r.mean()+1.96*ep:+.1%}", lucro_120=f"{x.r.sum()*120:,.0f}"))
print(f"apostas de LAY-under com xGOT: {len(d)} | base: {resumo(d).to_dict()}\n")
print("quanto o time gatilho deixou de acertar o alvo (xGOT - xG, em gols):")
print(d.groupby(pd.cut(d.fin_gols, [-9, -0.5, -0.3, -0.15, 0, 9]), observed=True).apply(resumo).to_string())
print("\nquanto o goleiro pegou (gols - xGOT, em gols; mais negativo = pegou mais):")
print(d.groupby(pd.cut(d.gol_gols, [-9, -0.5, -0.3, -0.15, 0, 9]), observed=True).apply(resumo).to_string())
print("\nonde ficam os cortes (medianas) e como os valores se espalham:")
print(d[["fin_gols", "gol_gols", "gap"]].describe(percentiles=[.1, .25, .5, .75, .9]).round(3).to_string())
print("\ncruzando pela mediana das duas:")
d["fin_alta"] = d.fin_gols < d.fin_gols.median()      # finalizou pior que a mediana
d["gol_alta"] = d.gol_gols < d.gol_gols.median()      # goleiro pegou mais que a mediana
print(d.groupby(["fin_alta", "gol_alta"]).apply(resumo).to_string())
print("\nas duas contas cruzadas em faixas fixas (em gols):")
fx = pd.cut(d.fin_gols, [-9, -0.45, -0.25, -0.1, 9], labels=["errou muito o alvo", "errou bastante", "errou pouco", "acertou o alvo"])
gx = pd.cut(d.gol_gols, [-9, -0.5, -0.3, -0.15, 9], labels=["goleiro pegou muito", "pegou bastante", "pegou pouco", "fez mais que o xGOT"])
cru = d.groupby([fx, gx], observed=True).apply(resumo)
print(cru.to_string())
# corte único, sem escolher célula: fora só quem errou muito o alvo (xGOT - xG pior que -0,45)
d["errou_muito"] = d.fin_gols <= -0.45
print("\nCORTE ÚNICO: tirando só quem errou muito o alvo")
print(pd.DataFrame({"base (todas)": resumo(d), "sem quem errou muito": resumo(d[~d.errou_muito]),
                    "só quem errou muito": resumo(d[d.errou_muito])}).T.to_string())
print("\npor liga:"); print(d.groupby(["liga", "errou_muito"]).apply(resumo).to_string())
print("\npor temporada:"); print(d.groupby(["season", "errou_muito"]).apply(resumo).unstack("errou_muito").to_string())

print("\npor liga e por temporada (o grupo 'goleiro pegou muito, finalização normal'):")
bom = d[~d.fin_alta & d.gol_alta]
print(pd.concat([bom.groupby("liga").apply(resumo), bom.groupby("season").apply(resumo)]).to_string())
