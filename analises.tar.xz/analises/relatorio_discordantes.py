# PDF: metade dos jogos de 21/22 em que o gatilho COMPLETO do LAY-over discorda (Understat x nosso modelo v7,
# liga nunca vista), sorteada proporcional por liga e grupo; para cada um, os jogos anteriores da janela de defesa
# dos dois times, com os dados do FotMob pedidos pelo usuário.
import sys, glob, gzip, json, os
sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer, Table, TableStyle,
                                PageBreak, KeepTogether)
from reportlab.platypus.tableofcontents import TableOfContents

SAIDA = "modelo_xg/relatorios/discordantes_lay_over_2122.pdf"
PASTA = {"Serie_A": "serie_a", "La_liga": "la_liga"}
NOME_LIGA = {"Serie_A": "Serie A", "La_liga": "La Liga"}
TZ = "America/Sao_Paulo"

# ---------------------------------------------------------------- 1. jogos discordantes de 21/22
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")

def serie(j, col, liga):
    w, lim = t.LAY_OVER[liga]
    sofr = j.rename(columns={"time": "adversario", "adversario": "time", col: "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
    x = j[["f_arq", "data", "season", "time", col, "gols"]].rename(columns={col: "xg"}).merge(sofr, on=["f_arq", "time"]).sort_values("data")
    g = x.groupby("time"); ant = lambda s, n: s.rolling(n).mean().shift(1)
    xga_w, gs_w = g.xga.transform(lambda s: ant(s, w)), g.gs.transform(lambda s: ant(s, w))
    xg4, gl4 = g.xg.transform(lambda s: ant(s, 4)), g.gols.transform(lambda s: ant(s, 4))
    x["defesa"] = (gs_w - xga_w) / xga_w >= lim
    x["ataque"] = ((xg4 - gl4) / xg4 >= 0.35) & (xg4 > gl4)
    x["ok"] = xga_w.notna() & xg4.notna()
    return x

casos, sequencias = [], {}
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    U, M = serie(j, "xg_u", b), serie(j, "xg_soma", b)
    ku = U.groupby("f_arq").agg(d=("defesa", "any"), a=("ataque", "any"), ok=("ok", "all"), season=("season", "first"), data=("data", "first"))
    km = M.groupby("f_arq").agg(d=("defesa", "any"), a=("ataque", "any"))
    k = ku.join(km, rsuffix="_m"); k = k[k.ok & (k.season == 2021)]
    k["u"], k["m"] = k.d & ~k.a, k.d_m & ~k.a_m
    for f, r in k[k.u != k.m].iterrows():
        casos.append(dict(liga=b, f_arq=f, data=r.data, grupo="Understat" if r.u else "Nosso"))
    sequencias[b] = U[["f_arq", "data", "time"]].sort_values("data")
casos = pd.DataFrame(casos)

# metade, proporcional por liga e grupo (maiores restos), sorteio com semente fixa
cont = casos.groupby(["liga", "grupo"]).size()
alvo = cont / 2
n = np.floor(alvo).astype(int)
faltam = int(round(len(casos) / 2)) - n.sum()
for idx in (alvo - n).sort_values(ascending=False).index[:faltam]:
    n[idx] += 1
rng = np.random.default_rng(2122)
escolhidos = pd.concat([g.iloc[rng.choice(len(g), n[k], replace=False)] for k, g in casos.groupby(["liga", "grupo"])])
escolhidos = escolhidos.sort_values("data").reset_index(drop=True)
print("discordantes:", cont.to_dict(), "| escolhidos:", n.to_dict())

# ---------------------------------------------------------------- 2. leitura do FotMob
_cache = {}
def ler(liga, arq):
    if arq not in _cache:
        caminho = glob.glob(f"data/bruto/fotmob/{PASTA[liga]}/*/{arq}")[0]
        with gzip.open(caminho) as fh:
            _cache[arq] = json.load(fh)
    return _cache[arq]

# todos os jogos das duas ligas (para tabela de classificação antes de cada jogo)
jogos_liga = {}
for liga, pasta in PASTA.items():
    linhas = []
    for f in glob.glob(f"data/bruto/fotmob/{pasta}/202[0-4]/*.json.gz"):
        if f.endswith("liga.json.gz"): continue
        arq = os.path.basename(f)
        d = ler(liga, arq); g = d["general"]; h = d["header"]["teams"]
        linhas.append(dict(arq=arq, temporada=f.split("/")[-2], data=pd.Timestamp(g["matchTimeUTC"]).tz_convert(TZ),
                           casa=g["homeTeam"]["id"], fora=g["awayTeam"]["id"], nome_casa=g["homeTeam"]["name"],
                           nome_fora=g["awayTeam"]["name"], gc=h[0]["score"], gf=h[1]["score"]))
    jogos_liga[liga] = pd.DataFrame(linhas)

def posicao(liga, arq, time):
    # posição na tabela da temporada ANTES do dia do jogo (pontos, saldo, gols pró)
    J = jogos_liga[liga]; jogo = J[J.arq == arq].iloc[0]
    ant = J[(J.temporada == jogo.temporada) & (J.data.dt.normalize() < jogo.data.normalize())]
    if ant.empty:
        return "1ª rodada", 0
    tab = {}
    for r in ant.itertuples():
        for tm, gp, gc in ((r.casa, r.gc, r.gf), (r.fora, r.gf, r.gc)):
            s = tab.setdefault(tm, [0, 0, 0, 0])
            s[0] += 3 if gp > gc else (1 if gp == gc else 0); s[1] += gp - gc; s[2] += gp; s[3] += 1
    ordem = sorted(tab, key=lambda k: (-tab[k][0], -tab[k][1], -tab[k][2]))
    if time not in tab:
        return "1ª rodada", 0
    p = tab[time]
    return f"{ordem.index(time) + 1}º ({p[0]} pts em {p[3]} jogos, saldo {p[1]:+d})", ordem.index(time) + 1

def valor(v):
    return "—" if v is None else str(v)

def estat(d, chave):
    for grp in d["content"]["stats"]["Periods"]["All"]["stats"]:
        for s in grp["stats"]:
            if s.get("key") == chave and s.get("stats") and s["stats"][0] is not None:
                return s["stats"]
    return [None, None]

ESTATS = [("BallPossesion", "Posse de bola (%)"), ("total_shots", "Chutes"), ("ShotsOnTarget", "Chutes no alvo"),
          ("ShotsOffTarget", "Chutes para fora"), ("blocked_shots", "Chutes bloqueados"), ("shots_woodwork", "Na trave"),
          ("shots_inside_box", "Chutes dentro da área"), ("shots_outside_box", "Chutes fora da área"),
          ("big_chance", "Grandes chances"), ("big_chance_missed_title", "Grandes chances perdidas"),
          ("accurate_passes", "Passes certos"), ("opposition_half_passes", "Passes no campo de ataque"),
          ("long_balls_accurate", "Bolas longas certas"), ("accurate_crosses", "Cruzamentos certos"),
          ("player_throws", "Laterais"), ("Offsides", "Impedimentos"), ("matchstats.headers.tackles", "Desarmes"),
          ("interceptions", "Interceptações"), ("shot_blocks", "Bloqueios"), ("clearances", "Cortes"),
          ("keeper_saves", "Defesas do goleiro"), ("ground_duels_won", "Duelos no chão ganhos"),
          ("aerials_won", "Duelos aéreos ganhos"), ("dribbles_succeeded", "Dribles certos"), ("fouls", "Faltas cometidas"),
          ("yellow_cards", "Amarelos"), ("red_cards", "Vermelhos"), ("corners", "Escanteios")]
JOG = {"rating_title": "nota", "errors_led_to_goal": "erros", "penalties_won": "pen_sof", "conceded_penalties": "pen_com",
       "missed_penalty": "pen_perd", "saves": "defesas", "goals_conceded": "gols_sof", "keeper_sweeper": "saidas", "punches": "socos",
       "minutes_played": "min"}

def jogadores(d, time_id):
    out = []
    lu = d["content"]["lineup"]
    lado = "homeTeam" if lu["homeTeam"]["id"] == time_id else "awayTeam"
    tit = {s["id"] for s in lu[lado].get("starters") or []}
    for p in (d["content"].get("playerStats") or {}).values():
        if p.get("teamId") != time_id: continue
        v = {}
        for grp in p.get("stats") or []:
            for s in (grp.get("stats") or {}).values():
                if s.get("key") in JOG:
                    v[JOG[s["key"]]] = (s.get("stat") or {}).get("value")
        out.append(dict(nome=p["name"], tit=p["id"] in tit, gk=p.get("isGoalkeeper"), **v))
    out.sort(key=lambda r: (not r["tit"], not r["gk"], r["nome"]))
    return out, lu[lado]

def eventos(d, casa_nome, fora_nome):
    out = []
    placar = [0, 0]
    for e in (d["content"]["matchFacts"].get("events") or {}).get("events") or []:
        minuto = f"{e.get('time')}'" + (f"+{e['overloadTime']}" if e.get("overloadTime") else "")
        lado = casa_nome if e.get("isHome") else fora_nome
        tp = e.get("type")
        if tp == "Goal":
            extra = " (gol contra)" if e.get("ownGoal") else ""
            placar[0 if e.get("isHome") else 1] += 1
            out.append((minuto, lado, f"Gol — {(e.get('player') or {}).get('name')}{extra} ({placar[0]} x {placar[1]})"))
        elif tp == "Card":
            cor = {"Yellow": "Amarelo", "Red": "Vermelho", "YellowRed": "2º amarelo (vermelho)"}.get(e.get("card"), e.get("card"))
            out.append((minuto, lado, f"{cor} — {(e.get('player') or {}).get('name')}"))
        elif tp == "Substitution":
            sw = e.get("swap") or [{}, {}]
            out.append((minuto, lado, f"Substituição — entra {sw[0].get('name')}, sai {sw[1].get('name') if len(sw) > 1 else '?'}"))
        elif tp == "AddedTime":
            import re
            num = re.findall(r"\d+", str(e.get("minutesAddedStr") or e.get("minutesAdded") or ""))
            out.append((minuto, "", f"Acréscimos: {num[0] if num else '?'} min"))
    return out

def forma(d, time_nome, data_jogo):
    tf = d["content"]["matchFacts"].get("teamForm") or []
    lado = 0 if d["general"]["homeTeam"]["name"] == time_nome else 1
    if len(tf) <= lado: return "—"
    itens = []
    for x in tf[lado]:
        dt = pd.Timestamp(x["date"]["utcTime"])
        if dt.tz_convert(TZ) >= data_jogo: continue
        tt = x.get("tooltipText") or {}
        itens.append(f"{x.get('resultString')} {tt.get('homeTeam')} {tt.get('homeScore')}x{tt.get('awayScore')} {tt.get('awayTeam')} ({dt.tz_convert(TZ):%d/%m})")
    return "; ".join(itens) if itens else "—"

def confronto(d, data_jogo, casa_id):
    ms = (d["content"].get("h2h") or {}).get("matches") or []
    linhas = []
    for x in ms:
        st = x.get("status") or {}
        dt = pd.Timestamp(x["time"]["utcTime"]).tz_convert(TZ)
        if not st.get("finished") or dt >= data_jogo: continue
        linhas.append(f"{dt:%d/%m/%Y} {x['home']['name']} {st.get('scoreStr', '?').replace(' - ', ' x ')} {x['away']['name']}")
    return linhas[:6]

# ---------------------------------------------------------------- 3. PDF
pdfmetrics.registerFont(TTFont("DV", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DVB", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
st = getSampleStyleSheet()
S = {k: ParagraphStyle(k, parent=st["Normal"], fontName="DV", fontSize=8, leading=10) for k in ("p",)}
S["h1"] = ParagraphStyle("h1", fontName="DVB", fontSize=17, leading=21, spaceAfter=4, textColor=colors.HexColor("#1f2a44"))
S["sub"] = ParagraphStyle("sub", fontName="DVB", fontSize=12, leading=15, spaceAfter=6, textColor=colors.HexColor("#b4541a"))
S["h2"] = ParagraphStyle("h2", fontName="DVB", fontSize=12, leading=15, spaceBefore=10, spaceAfter=4, textColor=colors.HexColor("#1f2a44"))
S["h3"] = ParagraphStyle("h3", fontName="DVB", fontSize=9.5, leading=12, spaceBefore=6, spaceAfter=3)
S["info"] = ParagraphStyle("info", fontName="DV", fontSize=9.5, leading=13)
S["toc1"] = ParagraphStyle("toc1", fontName="DV", fontSize=9, leading=12)

class Doc(BaseDocTemplate):
    def afterFlowable(self, fl):
        if isinstance(fl, Paragraph) and fl.style.name == "h1":
            self.notify("TOCEntry", (0, fl.getPlainText(), self.page))

def rodape(canvas, doc):
    canvas.saveState(); canvas.setFont("DV", 7); canvas.setFillColor(colors.grey)
    canvas.drawString(1.5 * cm, 1 * cm, "Jogos discordantes do LAY-over — 21/22 — dados FotMob")
    canvas.drawRightString(A4[0] - 1.5 * cm, 1 * cm, f"página {doc.page}")
    canvas.restoreState()

def tabela(dados, larguras, cab=True, zebra=True, tamanho=7.2, pad=6):
    tb = Table(dados, colWidths=larguras, repeatRows=1 if cab else 0)
    estilo = [("FONT", (0, 0), (-1, -1), "DV", tamanho), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
              ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#c8ccd4")), ("TOPPADDING", (0, 0), (-1, -1), 1.5),
              ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5),
              ("LEFTPADDING", (0, 0), (-1, -1), pad), ("RIGHTPADDING", (0, 0), (-1, -1), pad)]
    if cab:
        estilo += [("FONT", (0, 0), (-1, 0), "DVB", tamanho), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e6e9f0"))]
    if zebra:
        for i in range(1 if cab else 0, len(dados)):
            if i % 2 == 0: estilo.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#f7f8fb")))
    tb.setStyle(TableStyle(estilo)); return tb

W = A4[0] - 3 * cm
doc = Doc(SAIDA, pagesize=A4, leftMargin=1.5 * cm, rightMargin=1.5 * cm, topMargin=1.4 * cm, bottomMargin=1.6 * cm,
          title="Jogos discordantes do LAY-over 21/22")
doc.addPageTemplates([PageTemplate("p", [Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="f")], onPage=rodape)])
hist = []
hist.append(Paragraph("Jogos discordantes do LAY-over — 21/22", ParagraphStyle("capa", fontName="DVB", fontSize=20, leading=26)))
hist.append(Paragraph(f"{len(escolhidos)} de {len(casos)} jogos em que o gatilho do LAY-over (defesa sem exclusão de ataque) "
                      "disparou numa régua e não na outra: <b>Understat</b> = só a Understat disparou; <b>Nosso</b> = só o nosso modelo. "
                      "Sorteio proporcional por liga e por régua. Para cada jogo, os jogos anteriores dos dois times que entram no gap "
                      "de defesa (Serie A: 2, La Liga: 3). Datas no horário de Brasília. Posição na tabela: antes do dia do jogo.", S["info"]))
hist.append(Spacer(1, 8))
toc = TableOfContents(); toc.levelStyles = [S["toc1"]]; hist += [toc, PageBreak()]

for n_cap, caso in enumerate(escolhidos.itertuples(), 1):
    d0 = ler(caso.liga, caso.f_arq); g0 = d0["general"]
    dt0 = pd.Timestamp(g0["matchTimeUTC"]).tz_convert(TZ)
    casa, fora = g0["homeTeam"], g0["awayTeam"]
    hist.append(Paragraph(f"{n_cap}. {casa['name']} x {fora['name']}", S["h1"]))
    hist.append(Paragraph(caso.grupo, S["sub"]))
    pc, pf = posicao(caso.liga, caso.f_arq, casa["id"])[0], posicao(caso.liga, caso.f_arq, fora["id"])[0]
    hist.append(Paragraph(f"{NOME_LIGA[caso.liga]} — {dt0:%d/%m/%Y %H:%M}<br/>Mandante: <b>{casa['name']}</b> — {pc}<br/>"
                          f"Visitante: <b>{fora['name']}</b> — {pf}", S["info"]))
    w = t.LAY_OVER[caso.liga][0]
    seq = sequencias[caso.liga]
    for time in (casa, fora):
        s = seq[seq.time == time["id"]].reset_index(drop=True)
        pos = s.index[s.f_arq == caso.f_arq][0]
        hist.append(Paragraph(f"{time['name']} — {w} jogos anteriores", S["h2"]))
        for arq in s.iloc[max(pos - w, 0):pos].f_arq:
            d = ler(caso.liga, arq); g = d["general"]; h = d["header"]["teams"]
            dt = pd.Timestamp(g["matchTimeUTC"]).tz_convert(TZ)
            nc, nf = g["homeTeam"]["name"], g["awayTeam"]["name"]
            bloco = [Paragraph(f"{dt:%d/%m/%Y} — {nc} {h[0]['score']} x {h[1]['score']} {nf}", S["h3"]),
                     Paragraph(f"Posição antes do jogo: {nc} {posicao(caso.liga, arq, g['homeTeam']['id'])[0]}; "
                               f"{nf} {posicao(caso.liga, arq, g['awayTeam']['id'])[0]}", S["p"])]
            linhas = [["Estatística", nc, nf]] + [[rot] + [valor(v) for v in estat(d, k)] for k, rot in ESTATS]
            bloco.append(tabela(linhas, [W * 0.44, W * 0.28, W * 0.28]))
            hist.append(KeepTogether(bloco))
            for tid, tn in ((g["homeTeam"]["id"], nc), (g["awayTeam"]["id"], nf)):
                js, lu = jogadores(d, tid)
                cabp = ParagraphStyle("cab", fontName="DVB", fontSize=6.3, leading=7.4)
                cab = [Paragraph(x, cabp) for x in ["Jogador", "T/R", "Min", "Nota", "Erros → gol", "Pên. sofridos",
                                                    "Pên. cometidos", "Pên. perdidos", "Defesas", "Gols sofridos",
                                                    "Saídas do gol", "Socos"]]
                lin = [cab]
                for r in js:
                    gkv = [valor(r.get(k)) for k in ("defesas", "gols_sof", "saidas", "socos")] if r["gk"] else ["", "", "", ""]
                    lin.append([r["nome"], "T" if r["tit"] else "R", valor(r.get("min")), valor(r.get("nota")), valor(r.get("erros")),
                                valor(r.get("pen_sof")), valor(r.get("pen_com")), valor(r.get("pen_perd"))] + gkv)
                tecnico = (lu.get("coach") or {}).get("name") or "—"
                MOTIVO = {"injury": "lesão", "suspension": "suspensão", "international": "seleção", "other": "outro"}
                desf = ", ".join(f"{u.get('name')} ({MOTIVO.get(str((u.get('unavailability') or {}).get('type')).lower(), (u.get('unavailability') or {}).get('type') or '?')})"
                                 for u in lu.get("unavailable") or []) or "nenhum registrado"
                hist.append(KeepTogether([Paragraph(f"{tn} — técnico: {tecnico}", S["h3"]),
                                          tabela(lin, [W * 0.22, W * 0.04, W * 0.045, W * 0.055] + [W * 0.08] * 8, tamanho=6.6, pad=2)]))
                hist.append(Paragraph(f"T = titular, R = reserva (Min — = não entrou). Defesas, gols sofridos, saídas do gol e socos: só goleiro.<br/><b>Desfalques:</b> {desf}<br/>"
                                      f"<b>Forma antes do jogo (últimos jogos como o FotMob mostra, pode incluir copa e amistoso):</b> {forma(d, tn, dt)}", S["p"]))
            ev = eventos(d, nc, nf)
            if ev:
                hist.append(KeepTogether([Paragraph("Eventos", S["h3"]),
                                          tabela([["Min", "Time", "Evento"]] + [list(e) for e in ev], [W * 0.08, W * 0.22, W * 0.70])]))
            cf = confronto(d, dt, g["homeTeam"]["id"])
            hist.append(Paragraph("<b>Confronto direto (antes do jogo):</b> " + ("; ".join(cf) if cf else "—"), S["p"]))
            hist.append(Spacer(1, 6))
    hist.append(PageBreak())

os.makedirs(os.path.dirname(SAIDA), exist_ok=True)
doc.multiBuild(hist)
print("PDF:", SAIDA)
