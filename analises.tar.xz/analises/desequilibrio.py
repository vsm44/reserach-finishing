# Compressão e discordância concentram nos jogos DESEQUILIBRADOS? (v7, liga nunca vista)
# Força antes do jogo = saldo de gols por jogo na média móvel dos jogos anteriores (gf_ant - gs_ant)
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")

todos, janelas = [], []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    w, lim = t.LAY_OVER[b]
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    # força de cada time antes do jogo (do lado de quem chuta: atq_; do adversário: def_)
    f = te.groupby(["f_arq", "time"]).agg(forca_time=("atq_gf_ant", "first"), gs_time=("atq_gs_ant", "first"),
                                          forca_adv=("def_gf_ant", "first"), gs_adv=("def_gs_ant", "first")).reset_index()
    f["saldo_time"], f["saldo_adv"] = f.forca_time - f.gs_time, f.forca_adv - f.gs_adv
    j = j.merge(f[["f_arq", "time", "saldo_time", "saldo_adv"]], on=["f_arq", "time"])
    # visão de quem SOFRE: xGA do time = xG do adversário; desequilíbrio = força do time - força do adversário
    s = j.rename(columns={"time": "adversario", "adversario": "time", "xg_u": "xga_u", "xg_soma": "xga_m",
                          "saldo_time": "saldo_adv2", "saldo_adv": "saldo_time2"})
    s["deseq"] = s.saldo_time2 - s.saldo_adv2
    s["liga"] = b
    todos.append(s[["liga", "f_arq", "data", "time", "adversario", "mandante", "xga_u", "xga_m", "deseq"]])
d = pd.concat(todos)
d["mandante_sofre"] = 1 - d.mandante      # mandante da tabela era de quem chutava
d["faixa"] = pd.qcut(d.deseq, 5, labels=["time muito pior", "pior", "parelho", "melhor", "time muito melhor"])
print("xGA do time (o que ele SOFREU) por desequilíbrio de força antes do jogo:")
r = d.groupby("faixa", observed=True).apply(lambda x: pd.Series(dict(
    jogos=len(x), xga_understat=x.xga_u.mean(), modelo_sobre_understat=x.xga_m.sum() / x.xga_u.sum(),
    erro_rel=(np.abs(x.xga_m - x.xga_u) / x.xga_u.clip(lower=0.3)).mean(), baixo_05=(x.xga_u < 0.5).mean())))
print(r.round(3).to_string())
print("\nsó jogos com xGA da Understat < 0,5, por desequilíbrio e mando de quem sofre:")
x = d[d.xga_u < 0.5]
r2 = x.groupby(["faixa", "mandante_sofre"], observed=True).apply(lambda y: pd.Series(dict(jogos=len(y), modelo_sobre_understat=y.xga_m.sum() / y.xga_u.sum())))
print(r2.round(3).unstack().to_string())
