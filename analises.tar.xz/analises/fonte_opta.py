# LAY-over com a Opta como fonte, do lado do Understat: quem cada régua aponta e quanto rende.
# Grupos: só Understat, as duas, só Opta. Mesma janela, mesmo limiar, mesma exclusão de ataque,
# mesmos vermelhos e mesmas odds. A Opta vem do FotMob (xG por jogo), casada pelo calendário.
import sys, glob; sys.path.insert(0, "src")
import numpy as np, pandas as pd
import betedges.leagues as L
from betedges.cli import silencioso

opta = pd.read_csv("modelo_xg/dados/xgot_por_jogo.csv")
opta = opta[(opta.liga != "Portugal") & (opta.temporada >= 2020)].copy()
opta["data"] = pd.to_datetime(opta.data)

def serie_opta(liga, csv_glob, janela):
    # série por time e jogo com xG criado/sofrido da Opta e gols, casada com o football-data pelo calendário
    fd = pd.concat(pd.read_csv(f, usecols=["Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG"]) for f in sorted(glob.glob(csv_glob)))
    fd["dia"] = pd.to_datetime(fd.Date, dayfirst=True)
    x = opta[opta.liga == liga]
    votos = {}
    for j in x.itertuples():
        c = fd[(fd.FTHG == j.gols_mandante) & (fd.FTAG == j.gols_visitante) & ((fd.dia - j.data).abs() <= pd.Timedelta(days=1))]
        if len(c) == 1:
            for nf, nfd in ((j.mandante, c.HomeTeam.iloc[0]), (j.visitante, c.AwayTeam.iloc[0])):
                votos.setdefault(nf, {}).setdefault(nfd, 0); votos[nf][nfd] += 1
    mapa = {k: max(v, key=v.get) for k, v in votos.items()}
    linhas = []
    for lado, outro in (("mandante", "visitante"), ("visitante", "mandante")):
        linhas.append(pd.DataFrame(dict(date=x.data, team=x[lado].map(mapa), xg=x[f"xg_{lado}"], xga=x[f"xg_{outro}"],
                                        gols=x[f"gols_{lado}"], gols_sofridos=x[f"gols_{outro}"])))
    s = pd.concat(linhas).dropna(subset=["team", "xg"]).sort_values("date")
    g = s.groupby("team")
    ant = lambda c, n: g[c].transform(lambda v: v.rolling(n).mean().shift(1))
    s["gap_def"] = (ant("gols_sofridos", janela) - ant("xga", janela)) / ant("xga", janela)
    s["gap_atq"] = (ant("xg", 4) - ant("gols", 4)) / ant("xg", 4)
    return s[["date", "team", "gap_def", "gap_atq"]].dropna()

linhas = []
for lg in L.LEAGUES.values():
    w, lim = lg.lay_over
    s = serie_opta(lg.name, lg.csv_glob, w)
    capturas, original = [], L.completa_gols
    def espiao(c, nome, _cap=capturas, _orig=original):
        _cap.append(c.copy()); return _orig(c, nome)
    L.completa_gols = espiao
    with silencioso(True):
        L.build_league_bets(lg)
    L.completa_gols = original
    c = L.completa_gols(capturas[0], lg.name)       # base do Understat, com odds e sinais
    c["date"] = pd.to_datetime(c.kickoff).dt.normalize()
    verm = L.build_red_card_window_table(lg.csv_glob, short_window=w)
    for lado in ("home", "away"):
        c = c.merge(verm.rename(columns={"team": f"{lado}_team", "vermelhos_janela": f"{lado}_verm"}),
                    left_on=["kickoff", f"{lado}_team"], right_on=["Date", f"{lado}_team"], how="left").drop(columns=["Date"])
        c = c.merge(s.rename(columns={"team": f"{lado}_team", "gap_def": f"{lado}_def_opta", "gap_atq": f"{lado}_atq_opta", "date": "date"}),
                    on=["date", f"{lado}_team"], how="left")
    und_dfn = c.home_defensive_regression_applied | c.away_defensive_regression_applied
    und_atk = c.home_regression_applied | c.away_regression_applied
    opta_dfn = ((c.home_def_opta >= lim) | (c.away_def_opta >= lim)).fillna(False)
    opta_atk = ((c.home_atq_opta >= 0.35) | (c.away_atq_opta >= 0.35)).fillna(False)
    verm_und = ((c.home_defensive_regression_applied & (c.home_verm >= L.RED_CARD_LIMIAR).fillna(False))
                | (c.away_defensive_regression_applied & (c.away_verm >= L.RED_CARD_LIMIAR).fillna(False)))
    verm_opta = (((c.home_def_opta >= lim).fillna(False) & (c.home_verm >= L.RED_CARD_LIMIAR).fillna(False))
                 | ((c.away_def_opta >= lim).fillna(False) & (c.away_verm >= L.RED_CARD_LIMIAR).fillna(False)))
    c["ap_und"] = und_dfn & ~und_atk & ~verm_und
    c["ap_opta"] = opta_dfn & ~opta_atk & ~verm_opta
    c = c.dropna(subset=["over_back_price", "under_back_price"])
    c = c[~c.season_real.isin([2019]) & c[["home_def_opta", "away_def_opta"]].notna().any(axis=1)]
    linhas.append(pd.DataFrame(dict(liga=lg.name, season=c.season_real, date=c.kickoff, home=c.home_team, away=c.away_team,
                                    kind="LAY-over", market_odd=c.over_back_price,
                                    lay_odd=c.over_back_price * (1 + L.SPREAD_OVER_UNDER),
                                    win=(c.actual_total_goals <= 2.5), ap_und=c.ap_und, ap_opta=c.ap_opta)))
d = pd.concat(linhas, ignore_index=True)
d["r"] = L.ret(d)
d["fonte"] = np.select([d.ap_und & d.ap_opta, d.ap_und & ~d.ap_opta, ~d.ap_und & d.ap_opta], ["as duas", "só Understat", "só Opta"], "nenhuma")
def resumo(x):
    ep = x.r.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else np.nan
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}",
                          ic95=f"{x.r.mean()-1.96*ep:+.1%} a {x.r.mean()+1.96*ep:+.1%}", lucro_120=f"{x.r.sum()*120:,.0f}"))
ap = d[d.fonte != "nenhuma"]
print("LAY-over por fonte do gatilho\n"); print(ap.groupby("fonte").apply(resumo).to_string())
print("\ntotais:")
print(pd.DataFrame({"hoje (só Understat + as duas)": resumo(d[d.ap_und]), "só Opta como fonte": resumo(d[d.ap_opta]),
                    "união (qualquer uma)": resumo(ap)}).T.to_string())
print("\npor liga:"); print(ap.groupby(["liga", "fonte"]).apply(resumo).unstack("fonte").to_string())
print("\npor temporada:"); print(ap.groupby(["season", "fonte"]).apply(resumo).unstack("fonte").to_string())
