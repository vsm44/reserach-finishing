# Financeiro com stake diferente por grupo: LAY-over na faixa do xGOT, LAY-over fora da faixa (3,0%)
# e o resto das apostas em 3%. Procura o maior stake da faixa que não passa o drawdown oficial.
import inspect, sys; sys.path.insert(0, "src"); sys.path.insert(0, "scripts"); sys.path.insert(0, "modelo_xg/analises")
import numpy as np, pandas as pd
import financeiro as F
import gatilho_xgot as G

d = F.carrega()
faixa = G.d[(G.d.fin_gols > 0.3) & (G.d.fin_gols <= 0.5)][["liga", "date", "home", "away"]].copy()
faixa["date"] = pd.to_datetime(faixa.date); faixa["na_faixa"] = True
d["date"] = pd.to_datetime(d.date)
d = d.merge(faixa, on=["liga", "date", "home", "away"], how="left")
d["na_faixa"] = d.na_faixa.fillna(False) & (d.kind == "LAY-over")
d["fora_faixa"] = (d.kind == "LAY-over") & ~d.na_faixa

# roda() do financeiro com stake por grupo
codigo = inspect.getsource(F.roda).replace("def roda(", "def roda_g(M_FAIXA, M_FORA, ")
codigo = codigo.replace("        for b in grp.itertuples(index=False):\n",
                        "        for b in grp.itertuples(index=False):\n            m = M_FAIXA if b.na_faixa else (M_FORA if b.fora_faixa else 1.0)\n")
for a, b in (("l = _lucro(risco, b)", "l = _lucro(risco * m, b)"), ('a["volume"] += _stake(risco, b)', 'a["volume"] += _stake(risco * m, b)'),
             ("risco=risco, stake=_stake(risco, b)", "risco=risco * m, stake=_stake(risco * m, b)"),
             ("stake_flat=_stake(100.0, b)", "stake_flat=_stake(100.0 * m, b)"), ("lucro_flat=_lucro(100.0, b)", "lucro_flat=_lucro(100.0 * m, b)")):
    codigo = codigo.replace(a, b)
exec(codigo, vars(F))

anos, r0 = F.roda_g(1.0, 1.0, d)
print(f"oficial: banca {r0['banca_final']:,.0f} | drawdown {r0['mdd']:.1%}\n")
print("com 3,0% fora da faixa, variando o stake da faixa:")
print(f"{'stake faixa':>12} {'banca final':>14} {'drawdown':>10} {'lucro':>13}")
resultados = []
for pct in (3.3, 3.6, 4.0, 4.5):
    _, r = F.roda_g(pct / 3.0, 3.0 / 3.0, d)
    resultados.append((pct, r))
    print(f"{pct:>11.1f}% {r['banca_final']:>14,.0f} {r['mdd']:>9.1%} {r['lucro']:>13,.0f}")
cabe = [(p, r) for p, r in resultados if r["mdd"] <= r0["mdd"]]
escolha = max(cabe, key=lambda x: x[1]["banca_final"]) if cabe else resultados[0]
print(f"\nmaior stake na faixa sem passar o drawdown oficial ({r0['mdd']:.1%}): {escolha[0]:.1f}%")
anos, r = F.roda_g(escolha[0] / 3.0, 3.0 / 3.0, d)
det = r["detalhe"]
print(f"\n== FINANCEIRO com {escolha[0]:.1f}% na faixa e 3,0% fora ==  drawdown {r['mdd']:.1%}")
print(f"{'ano':>5} {'apostas':>8} {'volume':>13} {'lucro':>12} {'yield':>8} {'banca fim':>13}")
for a in anos.itertuples(index=False):
    print(f"{a.ano:>5} {a.n:>8} {a.volume:>13,.0f} {a.lucro:>12,.0f} {a.yld:>7.2%} {a.banca_fim:>13,.0f}")
print(f"TOTAL {r['n']:>8} {r['volume']:>13,.0f} {r['lucro']:>12,.0f} {r['lucro']/r['volume']:>7.2%} {r['banca_final']:>13,.0f}")
pv = 0.0
for a in anos.itertuples(index=False):
    fim = min(pd.Timestamp(int(a.ano), 12, 31), r["fim"]); dec = (fim - r["inicio"]).days / 365.25
    pv += (a.banca_fim - a.banca_ini) / (1 + F.INFLACAO) ** dec
perda = F.BANCA0 - F.BANCA0 / (1 + F.INFLACAO) ** r["n_anos"]
print(f"\nlucro líquido a valor de hoje: R$ {pv - F.FERRAMENTAS - perda:,.2f}")
