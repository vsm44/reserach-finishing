# Junta os chutes da Understat (La Liga e Serie A, 2019-2024) numa tabela só
import gzip, json, glob, sys
import pandas as pd
linhas = []
for liga in ("La_liga", "Serie_A"):
    for ano in range(2019, 2025):
        for f in glob.glob(f"data/bruto/understat/{liga}/{ano}/*.json.gz"):
            if f.endswith("liga.json.gz"): continue
            d = json.load(gzip.open(f))
            for lado in ("h", "a"):
                for s in d["shots"][lado]:
                    s = dict(s); s["liga"] = liga; linhas.append(s)
c = pd.DataFrame(linhas)
for col in ("X", "Y", "xG", "minute"): c[col] = c[col].astype(float)
c["season"] = c.season.astype(int)
c["time_chute"] = c.h_team.where(c.h_a == "h", c.a_team)
c["time_defesa"] = c.a_team.where(c.h_a == "h", c.h_team)
c.to_pickle(sys.argv[1])
print(len(c), "chutes;", c.match_id.nunique(), "jogos")
print(c.groupby(["liga", "season"]).size().unstack())
