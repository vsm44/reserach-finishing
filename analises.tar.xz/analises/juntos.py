# Os dois juntos no financeiro: Ligue 1 no under 2,5 (limiar 0,45) + 3,6% de stake nas apostas
# da faixa de xGOT do LAY-over (3% no resto).
import inspect, sys; sys.path.insert(0, "src"); sys.path.insert(0, "scripts"); sys.path.insert(0, "modelo_xg/analises")
import numpy as np, pandas as pd
import financeiro as F
import under_25 as U
import gatilho_xgot as G

lg = U.d[(U.d.liga == "Ligue 1") & (U.d.gap >= 0.45)].copy()
novas = pd.DataFrame(dict(date=pd.to_datetime(lg.date), liga="Ligue 1", kind="LAY-under", market_odd=lg.market_odd,
                          lay_odd=lg.lay_odd, win=lg.win, season=lg.season, home="", away="", p_fair=np.nan, occurred=~lg.win))
faixa = G.d[(G.d.fin_gols > 0.3) & (G.d.fin_gols <= 0.5)][["liga", "date", "home", "away"]].copy()
faixa["date"] = pd.to_datetime(faixa.date); faixa["na_faixa"] = True

def prepara(incluir_ligue1):
    d = F.carrega(); d["date"] = pd.to_datetime(d.date)
    if incluir_ligue1:
        d = pd.concat([d, novas], ignore_index=True).sort_values("date").reset_index(drop=True)
    d = d.merge(faixa, on=["liga", "date", "home", "away"], how="left")
    d["na_faixa"] = d.na_faixa.fillna(False) & (d.kind == "LAY-over")
    return d

codigo = inspect.getsource(F.roda).replace("def roda(", "def roda_m(MULT, ")
codigo = codigo.replace("        for b in grp.itertuples(index=False):\n",
                        "        for b in grp.itertuples(index=False):\n            m = MULT if b.na_faixa else 1.0\n")
for a, b in (("l = _lucro(risco, b)", "l = _lucro(risco * m, b)"), ('a["volume"] += _stake(risco, b)', 'a["volume"] += _stake(risco * m, b)'),
             ("risco=risco, stake=_stake(risco, b)", "risco=risco * m, stake=_stake(risco * m, b)"),
             ("stake_flat=_stake(100.0, b)", "stake_flat=_stake(100.0 * m, b)"), ("lucro_flat=_lucro(100.0, b)", "lucro_flat=_lucro(100.0 * m, b)")):
    codigo = codigo.replace(a, b)
exec(codigo, vars(F))

print(f"{'cenário':<42}{'apostas':>9}{'banca final':>15}{'yield':>9}{'drawdown':>11}")
for nome, lig, mult in (("oficial", False, 1.0), ("só 3,6% na faixa do xGOT", False, 1.2),
                        ("só Ligue 1 no under 2,5", True, 1.0), ("os dois juntos", True, 1.2)):
    anos, r = F.roda_m(mult, prepara(lig))
    print(f"{nome:<42}{r['n']:>9}{r['banca_final']:>15,.0f}{r['lucro']/r['volume']:>8.2%}{r['mdd']:>11.1%}")
    if nome == "os dois juntos":
        det = r["detalhe"]
        print("\nano a ano (os dois juntos):")
        for a in anos.itertuples(index=False):
            print(f"  {a.ano}  {a.n:>4} apostas  lucro {a.lucro:>11,.0f}  yield {a.yld:>6.2%}  banca {a.banca_fim:>12,.0f}")
        pv = 0.0
        for a in anos.itertuples(index=False):
            fim = min(pd.Timestamp(int(a.ano), 12, 31), r["fim"]); dec = (fim - r["inicio"]).days / 365.25
            pv += (a.banca_fim - a.banca_ini) / (1 + F.INFLACAO) ** dec
        perda = F.BANCA0 - F.BANCA0 / (1 + F.INFLACAO) ** r["n_anos"]
        print(f"\n  lucro líquido a valor de hoje: R$ {pv - F.FERRAMENTAS - perda:,.2f}")
