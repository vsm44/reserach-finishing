# LAY-over: troca a exclusão de ataque de (xG - gols)/xG para (xGOT - gols)/xGOT, mantendo todo o resto.
# Mesmo gatilho de defesa, mesma janela, mesmas odds. Compara N, acerto e ROI por temporada e por liga.
import sys, glob; sys.path.insert(0, "src")
import numpy as np, pandas as pd
import betedges.leagues as L
from betedges.cli import silencioso

LIMIAR_ATQ, JANELA_ATQ = 0.35, 4
# nomes do FotMob -> nomes do football-data, aprendidos pelo calendário (data + placar)
xgot = pd.read_csv("modelo_xg/dados/xgot_por_jogo.csv")
xgot = xgot[xgot.liga != "Portugal"].copy()
xgot["data"] = pd.to_datetime(xgot.data)

def serie_xgot(liga, csv_glob):
    # série por time e jogo com xGOT criado e gols, casada com o football-data pelo placar e data
    fd = pd.concat(pd.read_csv(f, usecols=["Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG"]) for f in sorted(glob.glob(csv_glob)))
    fd["dia"] = pd.to_datetime(fd.Date, dayfirst=True)
    x = xgot[xgot.liga == liga]
    votos = {}
    for j in x.itertuples():
        c = fd[(fd.FTHG == j.gols_mandante) & (fd.FTAG == j.gols_visitante) & ((fd.dia - j.data).abs() <= pd.Timedelta(days=1))]
        if len(c) == 1:
            for nome_f, nome_fd in ((j.mandante, c.HomeTeam.iloc[0]), (j.visitante, c.AwayTeam.iloc[0])):
                votos.setdefault(nome_f, {}).setdefault(nome_fd, 0); votos[nome_f][nome_fd] += 1
    mapa = {k: max(v, key=v.get) for k, v in votos.items()}
    linhas = []
    for lado, outro in (("mandante", "visitante"), ("visitante", "mandante")):
        linhas.append(pd.DataFrame(dict(Date=x.data, team=x[lado].map(mapa), xgot=x[f"xgot_{lado}"], gols=x[f"gols_{lado}"])))
    return pd.concat(linhas).dropna(subset=["team", "xgot"]).sort_values("Date")

def gap_xgot(liga, csv_glob):
    # gap ofensivo com xGOT: (xGOT - gols) / xGOT nos 4 jogos ANTERIORES
    s = serie_xgot(liga, csv_glob)
    g = s.groupby("team")
    ant = lambda c: g[c].transform(lambda v: v.rolling(JANELA_ATQ).mean().shift(1))
    s["gap_xgot"] = (ant("xgot") - ant("gols")) / ant("xgot")
    return s[["Date", "team", "gap_xgot"]].dropna()

resultados = []
for lg in L.LEAGUES.values():
    gaps = gap_xgot(lg.name, lg.csv_glob)
    # captura os sinais de cada lado antes do filtro, para reconstruir a aposta com a outra exclusão
    capturas = []
    original = L.completa_gols
    def espiao(c, nome, _cap=capturas, _orig=original):
        _cap.append(c.copy())
        return _orig(c, nome)
    L.completa_gols = espiao
    with silencioso(True):
        b = L.build_league_bets(lg)
    L.completa_gols = original
    over = b[b.kind == "LAY-over"].copy()
    c = capturas[0]          # a rodada do Understat (a mesma base do gatilho)
    c["date"] = pd.to_datetime(c.kickoff).dt.normalize()
    for lado in ("home", "away"):
        c = c.merge(gaps.rename(columns={"team": f"{lado}_team", "gap_xgot": f"{lado}_gap_xgot", "Date": "date"}),
                    on=["date", f"{lado}_team"], how="left")
    c["excl_xgot"] = ((c.home_gap_xgot >= LIMIAR_ATQ) | (c.away_gap_xgot >= LIMIAR_ATQ)).fillna(False)
    c["dfn"] = c.home_defensive_regression_applied | c.away_defensive_regression_applied
    chave = ["date", "home_team", "away_team"]
    m = c[chave + ["excl_xgot", "dfn"]].drop_duplicates(chave)
    over["date_n"] = pd.to_datetime(over.date).dt.normalize()
    over = over.merge(m.rename(columns={"home_team": "home", "away_team": "away", "date": "date_n"}), on=["date_n", "home", "away"], how="left")
    over["liga"] = lg.name
    resultados.append(over)
d = pd.concat(resultados, ignore_index=True)
d["r"] = L.ret(d)
d["stake"] = 1 / (d.lay_odd - 1)
# apostas de hoje (exclusão por xG, já aplicada) x apostas com a exclusão por xGOT
# as que a exclusão por xGOT tiraria:
sem_xgot = d[~d.excl_xgot.fillna(False)]
def resumo(x):
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}", lucro_120=f"{x.r.sum()*120:,.0f}"))
print("HOJE (exclusão por xG, como está na estratégia)"); print(d.groupby("liga").apply(resumo).to_string())
print("\ntotal:", resumo(d).to_dict())
print("\nTIRANDO TAMBÉM quem a exclusão por xGOT pegaria (as duas exclusões juntas)")
print(sem_xgot.groupby("liga").apply(resumo).to_string()); print("\ntotal:", resumo(sem_xgot).to_dict())
print("\nas apostas que a exclusão por xGOT tiraria:")
print(resumo(d[d.excl_xgot.fillna(False)]).to_dict())
print("\npor temporada (hoje x tirando as do xGOT):")
a = d.groupby("season").apply(resumo); b_ = sem_xgot.groupby("season").apply(resumo)
print(a.join(b_, lsuffix=" hoje", rsuffix=" sem xGOT").to_string())
