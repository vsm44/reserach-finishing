# Nos jogos em que o LAY-over COMPLETO discorda (v7, liga nunca vista): quais jogos ANTERIORES da janela
# mais erraram, e o que eles têm de diferente
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")

def serie(j, col, liga):
    # por time e jogo: xGA (o que sofreu) e xG, com as janelas ANTERIORES e o jogo que as compõe
    w, lim = t.LAY_OVER[liga]
    sofr = j.rename(columns={"time": "adversario", "adversario": "time", col: "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
    x = j[["f_arq", "data", "time", col, "gols"]].rename(columns={col: "xg"}).merge(sofr, on=["f_arq", "time"]).sort_values("data")
    g = x.groupby("time"); ant = lambda s, n: s.rolling(n).mean().shift(1)
    x["gap_def"] = (g.gs.transform(lambda s: ant(s, w)) - g.xga.transform(lambda s: ant(s, w))) / g.xga.transform(lambda s: ant(s, w))
    xg4, gl4 = g.xg.transform(lambda s: ant(s, 4)), g.gols.transform(lambda s: ant(s, 4))
    x["gap_atq"] = np.where(xg4 > gl4, (xg4 - gl4) / xg4, -1)
    x["defesa"], x["ataque"] = x.gap_def >= lim, x.gap_atq >= 0.35
    x["ordem"] = g.cumcount()
    return x

linhas_jogo, resumo = [], []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    w = t.LAY_OVER[b][0]
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    U, M = serie(j, "xg_u", b), serie(j, "xg_soma", b)
    k = U.merge(M[["f_arq", "time", "xga", "xg", "gap_def", "gap_atq", "defesa", "ataque"]], on=["f_arq", "time"], suffixes=("_u", "_m"))
    # por jogo da aposta: disparo completo em cada régua
    jm = k.groupby("f_arq").agg(du=("defesa_u", "any"), dm=("defesa_m", "any"), au=("ataque_u", "any"), am=("ataque_m", "any"))
    jm["cu"], jm["cm"] = jm.du & ~jm.au, jm.dm & ~jm.am
    disc = jm[jm.cu != jm.cm]
    # erro de cada jogo de cada time (modelo - Understat), em xGA e em xG
    k["err_xga"], k["err_xg"] = k.xga_m - k.xga_u, k.xg_m - k.xg_u
    # características do jogo de cada time vindas dos chutes: lado que SOFREU (para o xGA)
    carac = te.assign(_cab=te.parte == "Header", _pen=te.lance == "Penalty", _bola_parada=te.lance.isin(["FromCorner", "SetPiece", "FreeKick", "ThrowInSetPiece"]),
                      _contra=te.lance == "FastBreak", _perto=te.distancia < 11).groupby(["f_arq", "adversario"]).agg(
        chutes_sofridos=("gol", "size"), cab=("_cab", "sum"), pen=("_pen", "sum"), bola_parada=("_bola_parada", "sum"),
        contra_ataque=("_contra", "sum"), perto=("_perto", "sum"), gc=("gc_marcada", "sum"), gc_parcial=("grande_chance", lambda s: ((s > 0) & (s < 1)).sum()),
        gols_sofridos=("gol", "sum")).reset_index().rename(columns={"adversario": "time"})
    k = k.merge(carac, on=["f_arq", "time"], how="left")
    # para cada jogo discordante, os jogos da janela de defesa dos dois times
    idx = k.set_index(["time", "ordem"])
    for f in disc.index:
        for _, r in k[k.f_arq == f].iterrows():
            for o in range(r.ordem - w, r.ordem):
                if (r.time, o) in idx.index:
                    g = idx.loc[(r.time, o)]
                    linhas_jogo.append(dict(liga=b, err_xga=g.err_xga, xga_u=g.xga_u, **{kk: g[kk] for kk in carac.columns if kk not in ("f_arq", "time")}))
    k["liga"] = b
    resumo.append(k)
todos = pd.concat(resumo)
jan = pd.DataFrame(linhas_jogo)
todos["abs_rel"] = (todos.err_xga.abs() / todos.xga_u.clip(lower=0.3))
jan["abs_rel"] = jan.err_xga.abs() / jan.xga_u.clip(lower=0.3)
print(f"jogos das janelas dos casos discordantes: {len(jan)}  | todos os jogos: {len(todos)}")
print(f"erro relativo médio do xGA: janelas discordantes {jan.abs_rel.mean():.1%}  x  todos {todos.abs_rel.mean():.1%}")
print(f"erro médio do xGA (modelo - Understat): janelas discordantes {jan.err_xga.mean():+.3f}  x  todos {todos.err_xga.mean():+.3f}")
# quais características têm os jogos que MAIS erram (10% maiores erros relativos), comparados com o resto
todos["top"] = todos.abs_rel >= todos.abs_rel.quantile(0.9)
cols = ["xga_u", "chutes_sofridos", "cab", "pen", "bola_parada", "contra_ataque", "perto", "gc", "gc_parcial", "gols_sofridos"]
print("\nmédia por jogo: 10% que mais erram x resto")
print(todos.groupby("top")[cols].mean().T.rename(columns={False: "resto", True: "10% que mais erram"}).round(2).to_string())
print("\nerro médio do xGA por nº de pênaltis sofridos, cabeçadas e grandes chances parciais:")
for col, bins in (("pen", [-1, 0, 1, 5]), ("cab", [-1, 1, 3, 20]), ("gc_parcial", [-1, 0, 1, 20]), ("contra_ataque", [-1, 0, 1, 20])):
    print(todos.groupby(pd.cut(todos[col], bins), observed=True).agg(jogos=("err_xga", "size"), erro_medio=("err_xga", "mean"), erro_rel=("abs_rel", "mean")).round(3).to_string(), "\n")

print("erro do xGA por faixa de xGA da Understat no jogo (compressão aparece como + embaixo e - em cima):")
print(todos.groupby(pd.cut(todos.xga_u, [0, 0.5, 0.8, 1.2, 1.8, 2.5, 6]), observed=True).agg(
    jogos=("err_xga", "size"), erro_medio=("err_xga", "mean"), erro_rel_medio=("abs_rel", "mean"),
    modelo_sobre_understat=("xga_m", "sum")).assign(modelo_sobre_understat=lambda d: d.modelo_sobre_understat /
    todos.groupby(pd.cut(todos.xga_u, [0, 0.5, 0.8, 1.2, 1.8, 2.5, 6]), observed=True).xga_u.sum()).round(3).to_string())
print(f"\njanelas discordantes: xGA médio da Understat por jogo {jan.xga_u.mean():.2f} x todos {todos.xga_u.mean():.2f}")
