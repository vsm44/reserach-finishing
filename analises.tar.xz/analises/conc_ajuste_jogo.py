# v14: corrige o xG somado de cada time no jogo com o que só existe com o jogo pronto (xGOT, execução,
# gols contra xGOT). Mede a concordância por ano, do mesmo jeito que o conc_ano_cal, na liga nunca vista.
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
todos = []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    # treino da correção: xG de chute previsto sem a própria temporada, para não corrigir um modelo que viu as respostas
    tr = t.previsoes_fora_da_temporada(c[c.liga == a].dropna(subset=["xg_understat"]), t.V7, lambda df: pen)
    jtr = t.tabela_jogo(tr, "xg_modelo")
    aj = t.gbm().fit(jtr[t.JOGO], jtr.xg_u)
    j["xg_ajustado"] = np.clip(aj.predict(j[t.JOGO]), 0.0, None)
    for col, versao in (("xg_soma", "v7"), ("xg_ajustado", "v14")):
        gu, gm = t.gatilhos(j, "xg_u", b), t.gatilhos(j, col, b)
        gu, gm = gu.align(gm, join="inner")
        ano = j.groupby("f_arq").data.first().dt.year.reindex(gu.index)
        todos.append(pd.concat([gu.add_suffix("|u"), gm.add_suffix("|m")], axis=1).assign(ano=ano.values, versao=versao))
        if versao == "v14":
            print(f"{b}: nível {j.xg_ajustado.mean()/j.xg_u.mean():.3f} dispersão {j.xg_ajustado.std()/j.xg_u.std():.3f} "
                  f"correlação {j.xg_u.corr(j.xg_ajustado):.3f} (v7: {j.xg_u.corr(j.xg_soma):.3f})")
d = pd.concat(todos)
def tabela(x):
    return pd.Series({k: f"{(x[f'{k}|u'] & x[f'{k}|m']).sum() / max((x[f'{k}|u'] | x[f'{k}|m']).sum(), 1):.1%}"
                      for k in ("LAY-over defesa", "LAY-over completo", "LAY-under")})
print("\nconcordância por ano")
print(d.groupby(["versao", "ano"]).apply(tabela).to_string())
print("\ntotal"); print(d.groupby("versao").apply(tabela).to_string())
