# Excel dos mesmos 20 jogos discordantes do PDF (21/22, sorteio com semente 2122): quem disparou o gatilho
# de defesa do LAY-over em cada régua, e os jogos anteriores da janela desse time com gols, xG e xGA da
# Understat e do nosso modelo (v7, liga nunca vista).
import sys, glob, gzip, json, os
sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

SAIDA = "modelo_xg/relatorios/discordantes_lay_over_2122.xlsx"
PASTA = {"Serie_A": "serie_a", "La_liga": "la_liga"}
NOME_LIGA = {"Serie_A": "Serie A", "La_liga": "La Liga"}
TZ = "America/Sao_Paulo"
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")

def serie(j, col, liga):
    # por time e jogo: gols sofridos/marcados, xGA/xG do jogo e as janelas ANTERIORES (defesa e ataque)
    w, lim = t.LAY_OVER[liga]
    sofr = j.rename(columns={"time": "adversario", "adversario": "time", col: "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
    x = j[["f_arq", "data", "season", "time", "adversario", col, "gols"]].rename(columns={col: "xg"}).merge(sofr, on=["f_arq", "time"]).sort_values("data")
    g = x.groupby("time"); ant = lambda s, n: s.rolling(n).mean().shift(1)
    x["xga_w"], x["gs_w"] = g.xga.transform(lambda s: ant(s, w)), g.gs.transform(lambda s: ant(s, w))
    x["xg4"], x["gl4"] = g.xg.transform(lambda s: ant(s, 4)), g.gols.transform(lambda s: ant(s, 4))
    x["gap_def"] = (x.gs_w - x.xga_w) / x.xga_w
    x["gap_atq"] = np.where(x.xg4 > x.gl4, (x.xg4 - x.gl4) / x.xg4, 0.0)
    x["defesa"], x["ataque"] = x.gap_def >= lim, x.gap_atq >= 0.35
    x["ok"] = x.xga_w.notna() & x.xg4.notna()
    return x

casos, series = [], {}
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    U, M = serie(j, "xg_u", b), serie(j, "xg_soma", b)
    ku = U.groupby("f_arq").agg(d=("defesa", "any"), a=("ataque", "any"), ok=("ok", "all"), season=("season", "first"), data=("data", "first"))
    km = M.groupby("f_arq").agg(d=("defesa", "any"), a=("ataque", "any"))
    k = ku.join(km, rsuffix="_m"); k = k[k.ok & (k.season == 2021)]
    k["u"], k["m"] = k.d & ~k.a, k.d_m & ~k.a_m
    for f, r in k[k.u != k.m].iterrows():
        casos.append(dict(liga=b, f_arq=f, data=r.data, grupo="Understat" if r.u else "Nosso"))
    series[b] = (U, M)
casos = pd.DataFrame(casos)

# mesmo sorteio do PDF
cont = casos.groupby(["liga", "grupo"]).size()
alvo = cont / 2
n = np.floor(alvo).astype(int)
faltam = int(round(len(casos) / 2)) - n.sum()
for idx in (alvo - n).sort_values(ascending=False).index[:faltam]:
    n[idx] += 1
rng = np.random.default_rng(2122)
escolhidos = pd.concat([g.iloc[rng.choice(len(g), n[k], replace=False)] for k, g in casos.groupby(["liga", "grupo"])])
escolhidos = escolhidos.sort_values("data").reset_index(drop=True)

# nomes, placar e data (Brasília) de cada jogo
info = {}
for liga, pasta in PASTA.items():
    for f in glob.glob(f"data/bruto/fotmob/{pasta}/202[0-4]/*.json.gz"):
        if f.endswith("liga.json.gz"): continue
        with gzip.open(f) as fh:
            d = json.load(fh)
        g = d["general"]; h = d["header"]["teams"]
        info[os.path.basename(f)] = dict(data=pd.Timestamp(g["matchTimeUTC"]).tz_convert(TZ), casa=g["homeTeam"]["name"],
                                         fora=g["awayTeam"]["name"], hid=g["homeTeam"]["id"], aid=g["awayTeam"]["id"],
                                         placar=f"{h[0]['score']} x {h[1]['score']}")

resumo, anteriores = [], []
for n_jogo, caso in enumerate(escolhidos.itertuples(), 1):
    U, M = series[caso.liga]
    w, lim = t.LAY_OVER[caso.liga]
    i0 = info[caso.f_arq]
    jogo = f"{i0['casa']} x {i0['fora']}"
    lu, lm = U[U.f_arq == caso.f_arq].set_index("time"), M[M.f_arq == caso.f_arq].set_index("time")
    # time que disparou a defesa na régua do grupo; se discordou só pela exclusão de ataque, é o mesmo nas duas
    regua = lu if caso.grupo == "Understat" else lm
    disparou = [tm for tm in (i0["hid"], i0["aid"]) if regua.loc[tm, "defesa"]]
    for tm in disparou:
        nome = i0["casa"] if tm == i0["hid"] else i0["fora"]
        excl_u = "sim" if lu.ataque.any() else "não"
        excl_m = "sim" if lm.ataque.any() else "não"
        resumo.append({"Nº": n_jogo, "Data": i0["data"].strftime("%d/%m/%Y"), "Liga": NOME_LIGA[caso.liga], "Jogo": jogo,
                       "Só disparou em": caso.grupo, "Time que disparou": nome, "Mando": "casa" if tm == i0["hid"] else "fora",
                       "Janela (jogos)": w, "Limiar": lim,
                       "Gols sofridos (média)": round(lu.loc[tm, "gs_w"], 2),
                       "xGA Understat (média)": round(lu.loc[tm, "xga_w"], 2), "xGA Nosso (média)": round(lm.loc[tm, "xga_w"], 2),
                       "Gap defesa Understat": round(lu.loc[tm, "gap_def"], 3), "Gap defesa Nosso": round(lm.loc[tm, "gap_def"], 3),
                       "Defesa disparou Understat": "sim" if lu.loc[tm, "defesa"] else "não",
                       "Defesa disparou Nosso": "sim" if lm.loc[tm, "defesa"] else "não",
                       "Exclusão de ataque Understat": excl_u, "Exclusão de ataque Nosso": excl_m})
        su, sm = U[U.time == tm].reset_index(drop=True), M[M.time == tm].set_index("f_arq")
        pos = su.index[su.f_arq == caso.f_arq][0]
        for r in su.iloc[max(pos - w, 0):pos].itertuples():
            ii = info[r.f_arq]; rm = sm.loc[r.f_arq]
            anteriores.append({"Nº": n_jogo, "Jogo da aposta": jogo, "Só disparou em": caso.grupo, "Time que disparou": nome,
                               "Data": ii["data"].strftime("%d/%m/%Y"), "Jogo anterior": f"{ii['casa']} x {ii['fora']}",
                               "Placar": ii["placar"], "Mando do time": "casa" if tm == ii["hid"] else "fora",
                               "Gols sofridos": int(r.gs), "xGA Understat": round(r.xga, 2), "xGA Nosso": round(rm.xga, 2),
                               "Diferença xGA (Nosso − Understat)": round(rm.xga - r.xga, 2),
                               "Gols marcados": int(r.gols), "xG Understat": round(r.xg, 2), "xG Nosso": round(rm.xg, 2),
                               "Diferença xG (Nosso − Understat)": round(rm.xg - r.xg, 2)})

# planilha formatada
wb = Workbook()
def aba(ws, linhas, titulo, largura_min=10):
    ws.title = titulo
    cab = list(linhas[0].keys())
    ws.append(cab)
    for l in linhas:
        ws.append([l[k] for k in cab])
    borda = Side(style="thin", color="C8CCD4")
    for cel in ws[1]:
        cel.font = Font(bold=True, color="FFFFFF"); cel.fill = PatternFill("solid", fgColor="1F2A44")
        cel.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    ws.row_dimensions[1].height = 42
    cor = {"Understat": "FCE9DC", "Nosso": "E3ECF8"}
    for row in ws.iter_rows(min_row=2):
        grupo = row[cab.index("Só disparou em")].value
        for cel in row:
            cel.border = Border(top=borda, bottom=borda, left=borda, right=borda)
            cel.fill = PatternFill("solid", fgColor=cor.get(grupo, "FFFFFF"))
            cel.alignment = Alignment(vertical="center")
    for i, k in enumerate(cab, 1):
        maior = max(len(str(k)) * 0.6, *(len(str(l[k])) for l in linhas))
        ws.column_dimensions[get_column_letter(i)].width = max(largura_min, min(40, maior + 2))
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

aba(wb.active, resumo, "Quem disparou")
aba(wb.create_sheet(), anteriores, "Jogos anteriores")
leg = wb.create_sheet("Leia-me")
for linha in ["Mesmos 20 jogos do PDF (21/22, LAY-over completo discordante, sorteio proporcional, semente 2122).",
              "Só disparou em: Understat = só o gatilho com xG da Understat disparou; Nosso = só o gatilho com o nosso modelo (v7).",
              "Time que disparou: o time cuja defesa disparou na régua que apostou. Se os dois dispararam, aparecem duas linhas.",
              "Gap defesa = (média de gols sofridos − média de xGA) ÷ média de xGA nos jogos anteriores da janela (Serie A 2, La Liga 3). Dispara se ≥ 0,45.",
              "Exclusão de ataque: algum dos dois times com (xG − gols) ÷ xG ≥ 0,35 nos 4 jogos anteriores. Se 'sim', o jogo sai.",
              "Gols: placar oficial (conta gol contra). xG e xGA do nosso modelo: previsto por um modelo treinado só na OUTRA liga.",
              "Datas no horário de Brasília. Cores: laranja = Understat, azul = Nosso."]:
    leg.append([linha])
leg.column_dimensions["A"].width = 140
os.makedirs(os.path.dirname(SAIDA), exist_ok=True)
wb.save(SAIDA)
print(f"{len(resumo)} linhas em 'Quem disparou', {len(anteriores)} em 'Jogos anteriores' -> {SAIDA}")
