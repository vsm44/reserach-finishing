# LAY-under na Ligue 1: a liga nunca entrou nessa aposta. Mesma mecânica das outras duas
# (gap ofensivo = (xG - gols)/xG nos 3 jogos anteriores, odd do under 1,5, ganha se o jogo passa de 1,5),
# mostrando o resultado POR FAIXA DE GAP. O limiar é escolha do usuário; aqui só se mede.
import sys; sys.path.insert(0, "src")
import numpy as np, pandas as pd
import betedges.leagues as L
from betedges.data.regression_signal import build_offensive_gap_table, build_red_card_net_table
from betedges.data.sportmonks_odds import completa_gols
from betedges.cli import silencioso

linhas = []
for lg in L.LEAGUES.values():
    base = L.build_backtest_dataset(lg.paths(), league_key=lg.key, rolling_window=10, shrink_k=8,
                                    use_team_profiles=True, causal_profiles=True)
    smap = lg.season_map()
    c = base.copy()
    c["_k"] = pd.to_datetime(c["kickoff"]).dt.normalize()
    c = c.merge(smap[["home_team", "away_team", "_k", "season_real"]], on=["home_team", "away_team", "_k"], how="left")
    gap = build_offensive_gap_table(lg.csv_glob, lg.xg_csv, short_window=L.LAY_UNDER_JANELA)
    verm = build_red_card_net_table(lg.csv_glob, short_window=L.LAY_UNDER_JANELA)
    for lado in ("home", "away"):
        c = c.merge(gap.rename(columns={"team": f"{lado}_team", "gap_ofensivo": f"{lado}_gap"}),
                    left_on=["kickoff", f"{lado}_team"], right_on=["Date", f"{lado}_team"], how="left").drop(columns=["Date"])
        c = c.merge(verm.rename(columns={"team": f"{lado}_team", "vermelhos_liquidos": f"{lado}_verm"}),
                    left_on=["kickoff", f"{lado}_team"], right_on=["Date", f"{lado}_team"], how="left").drop(columns=["Date"])
    odds = L.carrega_under_15(lg.name)
    if not odds.empty:
        c = c.merge(odds, on=["_k", "home_team", "away_team"], how="left")
    else:
        c["under_15_price"] = np.nan; c["over_15_price"] = np.nan
    c = completa_gols(c, lg.name)
    falta = c.under_15_price.isna() & c.over_back_price.notna() & c.under_back_price.notna()
    if falta.any():   # deriva o 1,5 a partir do 2,5, como no motor
        p_under = L.deriva_under_15(c.loc[falta, "over_back_price"], c.loc[falta, "under_back_price"])
        c.loc[falta, "under_15_price"] = 1.0 / (p_under * L.MARGEM_UNDER_15)
        c.loc[falta, "over_15_price"] = 1.0 / ((1 - p_under) * L.MARGEM_UNDER_15)
    casa = c.home_gap >= c.away_gap
    c["gap"] = c[["home_gap", "away_gap"]].max(axis=1)
    c["verm"] = np.where(casa, c.home_verm, c.away_verm)
    c = c[c.under_15_price.notna() & c.over_15_price.notna() & c.gap.notna()]
    c = c[(c.verm >= L.LAY_UNDER_VERMELHO_MIN) & ~c.season_real.isin([2019])]
    linhas.append(pd.DataFrame(dict(liga=lg.name, season=c.season_real, kind="LAY-under", gap=c.gap,
                                    market_odd=c.under_15_price, lay_odd=c.under_15_price * (1 + L.SPREAD_OVER_UNDER),
                                    win=(c.actual_total_goals > 1.5))))
d = pd.concat(linhas, ignore_index=True)
d["r"] = L.ret(d)
def resumo(x):
    ep = x.r.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else np.nan
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}",
                          ic95=f"{x.r.mean()-1.96*ep:+.1%} a {x.r.mean()+1.96*ep:+.1%}", lucro_120=f"{x.r.sum()*120:,.0f}"))
faixas = pd.cut(d.gap, [-9, 0, 0.15, 0.25, 0.30, 0.35, 0.45, 9])
print("LAY-under por faixa de gap ofensivo, em cada liga (o limiar de hoje: La Liga 0,35 e Serie A 0,30)\n")
for liga, x in d.groupby("liga"):
    print(f"== {liga} ==")
    print(x.groupby(pd.cut(x.gap, [-9, 0, 0.15, 0.25, 0.30, 0.35, 0.45, 9]), observed=True).apply(resumo).to_string(), "\n")
print("Ligue 1, acumulado a partir de cada limiar:")
lg1 = d[d.liga == "Ligue 1"]
for lim in (0.20, 0.25, 0.30, 0.35, 0.40, 0.45):
    s = lg1[lg1.gap >= lim]
    print(f"  limiar {lim:.2f}: ", resumo(s).to_dict())
