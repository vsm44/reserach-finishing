# Concordância do gatilho por time (v7, liga nunca vista), separando o time que dispara em casa ou fora no jogo da aposta
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")

def por_time(j, col, liga):
    w, lim = t.LAY_OVER[liga]
    sofr = j.rename(columns={"time": "adversario", "adversario": "time", col: "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
    x = j[["f_arq", "data", "time", "mandante", col, "gols"]].rename(columns={col: "xg"}).merge(sofr, on=["f_arq", "time"]).sort_values("data")
    g = x.groupby("time"); ant = lambda s, n: s.rolling(n).mean().shift(1)
    xga_w, gs_w = g.xga.transform(lambda s: ant(s, w)), g.gs.transform(lambda s: ant(s, w))
    xg3, gl3 = g.xg.transform(lambda s: ant(s, 3)), g.gols.transform(lambda s: ant(s, 3))
    x["defesa"] = (gs_w - xga_w) / xga_w >= lim
    x["under"] = (xg3 - gl3) / xg3 >= t.LAY_UNDER[liga]
    x = x[xga_w.notna() & xg3.notna()]
    return x.set_index(["f_arq", "time"])[["mandante", "defesa", "under"]]

for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    U, M = por_time(j, "xg_u", b), por_time(j, "xg_soma", b)
    k = U.join(M[["defesa", "under"]], rsuffix="_m", how="inner")
    for gat in ("defesa", "under"):
        for mando, x in k.groupby("mandante"):
            u, mm = x[gat], x[f"{gat}_m"]
            print(f"{b:<8} {'LAY-over defesa' if gat=='defesa' else 'LAY-under':<16} {'em casa' if mando else 'fora':<8}"
                  f" U {int(u.sum()):>4}  M {int(mm.sum()):>4}  os dois {int((u&mm).sum()):>4}  só U {int((u&~mm).sum()):>3}  só M {int((~u&mm).sum()):>3}"
                  f" | concordância {(u&mm).sum()/(u|mm).sum():.1%}")
