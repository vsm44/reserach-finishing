# Ligue 1 no under 2,5 com limiar 0,45 (escolha do usuário): temporada a temporada e o efeito no financeiro.
import inspect, sys; sys.path.insert(0, "src"); sys.path.insert(0, "scripts"); sys.path.insert(0, "modelo_xg/analises")
import numpy as np, pandas as pd
import betedges.leagues as L
import financeiro as F
import under_25 as U

lg = U.d[(U.d.liga == "Ligue 1") & (U.d.gap >= 0.45)].copy()
def resumo(x):
    ep = x.r.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else np.nan
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}",
                          ic95=f"{x.r.mean()-1.96*ep:+.1%} a {x.r.mean()+1.96*ep:+.1%}", lucro_120=f"{x.r.sum()*120:,.0f}"))
print("Ligue 1, under 2,5, limiar 0,45")
print(resumo(lg).to_dict())
print("\npor temporada:"); print(lg.groupby("season").apply(resumo).to_string())
print("\npor período:")
print(pd.DataFrame({"20/21 a 22/23": resumo(lg[lg.season <= 2022]), "23/24 a 25/26": resumo(lg[lg.season >= 2023])}).T.to_string())

# financeiro: junta essas apostas às da operação
novas = pd.DataFrame(dict(date=pd.to_datetime(lg.date if "date" in lg else lg.index), liga="Ligue 1", kind="LAY-under",
                          market_odd=lg.market_odd, lay_odd=lg.lay_odd, win=lg.win, season=lg.season,
                          home="", away="", p_fair=np.nan, occurred=~lg.win))
d = pd.concat([F.carrega(), novas], ignore_index=True).sort_values("date").reset_index(drop=True)
for nome, base in (("OFICIAL", F.carrega()), ("COM a Ligue 1 no under 2,5", d)):
    anos, r = F.roda(base)
    print(f"\n== {nome} ==  apostas {r['n']}  banca {r['banca_final']:,.0f}  yield {r['lucro']/r['volume']:.2%}  drawdown {r['mdd']:.1%}")
