# Concordância do gatilho do LAY-under (v7): (xG - gols) / xG nos 3 jogos ANTERIORES; jogo dispara se o maior
# gap dos dois times >= limiar (Serie A 0,30, La Liga 0,35). Sem vermelhos nem odds.
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
LIM = {"Serie_A": 0.30, "La_liga": 0.35}
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
base = c[c.lance != "Penalty"].dropna(subset=["xg_understat"])
pen = c[c.lance == "Penalty"].dropna(subset=["xg_understat"]).groupby("liga").xg_understat.median()

def dispara_under(x, col, liga):
    # xG e gols de cada time por jogo -> janela dos 3 jogos anteriores -> maior gap do jogo
    j = x.groupby(["f_arq", "data", "time"]).agg(xg=(col, "sum"), gols=("gol", "sum")).reset_index().sort_values("data")
    g = j.groupby("time")
    j["xg_w"] = g.xg.transform(lambda s: s.rolling(3).mean().shift(1))
    j["gols_w"] = g.gols.transform(lambda s: s.rolling(3).mean().shift(1))
    j["gap"] = (j.xg_w - j.gols_w) / j.xg_w
    m = j.groupby("f_arq").gap.max()
    return m.dropna() >= LIM[liga]

def mede(te, nome):
    for liga, x in te.groupby("liga"):
        x = x.dropna(subset=["xg_understat"])
        du, dm = dispara_under(x, "xg_understat", liga), dispara_under(x, "xg_modelo", liga)
        du, dm = du.align(dm, join="inner")
        print(f"{nome:<28} {liga:<8} jogos {len(du):>5} | Understat dispara {int(du.sum()):>4}, modelo {int(dm.sum()):>4}, os dois {int((du&dm).sum()):>4}"
              f" | concordância {(du&dm).sum()/(du|dm).sum():.1%}")

tr = base[base.season <= 2023]; m = t.treina(tr, t.V7)
te = c[c.season == 2024].copy(); te["xg_modelo"] = t.preve(m, te, t.V7, te.liga.map(pen)); mede(te, "tempo (testa 24/25)")
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    m = t.treina(base[base.liga == a], t.V7)
    te = c[c.liga == b].copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen[a]); mede(te, f"liga (treina {a})")
