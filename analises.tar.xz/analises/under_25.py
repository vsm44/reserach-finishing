# LAY no under 2,5 (ganha com 3 gols ou mais), com o mesmo gatilho do LAY-under: time devendo gol.
# Odd do under 2,5 é a Pinnacle do football-data. Mostra por faixa de gap e nos limiares de hoje.
import sys; sys.path.insert(0, "src")
import numpy as np, pandas as pd
import betedges.leagues as L
from betedges.data.regression_signal import build_offensive_gap_table, build_red_card_net_table
from betedges.data.sportmonks_odds import completa_gols

linhas = []
for lg in L.LEAGUES.values():
    base = L.build_backtest_dataset(lg.paths(), league_key=lg.key, rolling_window=10, shrink_k=8,
                                    use_team_profiles=True, causal_profiles=True)
    smap = lg.season_map()
    c = base.copy(); c["_k"] = pd.to_datetime(c["kickoff"]).dt.normalize()
    c = c.merge(smap[["home_team", "away_team", "_k", "season_real"]], on=["home_team", "away_team", "_k"], how="left")
    gap = build_offensive_gap_table(lg.csv_glob, lg.xg_csv, short_window=L.LAY_UNDER_JANELA)
    verm = build_red_card_net_table(lg.csv_glob, short_window=L.LAY_UNDER_JANELA)
    for lado in ("home", "away"):
        c = c.merge(gap.rename(columns={"team": f"{lado}_team", "gap_ofensivo": f"{lado}_gap"}),
                    left_on=["kickoff", f"{lado}_team"], right_on=["Date", f"{lado}_team"], how="left").drop(columns=["Date"])
        c = c.merge(verm.rename(columns={"team": f"{lado}_team", "vermelhos_liquidos": f"{lado}_verm"}),
                    left_on=["kickoff", f"{lado}_team"], right_on=["Date", f"{lado}_team"], how="left").drop(columns=["Date"])
    c = completa_gols(c, lg.name)     # traz over/under 2,5 da Pinnacle (com reserva)
    casa = c.home_gap >= c.away_gap
    c["gap"] = c[["home_gap", "away_gap"]].max(axis=1)
    c["verm"] = np.where(casa, c.home_verm, c.away_verm)
    c = c[c.under_back_price.notna() & c.gap.notna() & (c.verm >= L.LAY_UNDER_VERMELHO_MIN) & ~c.season_real.isin([2019])]
    linhas.append(pd.DataFrame(dict(liga=lg.name, season=c.season_real, date=c.kickoff, home=c.home_team, away=c.away_team,
                                    kind="LAY-under", gap=c.gap,
                                    market_odd=c.under_back_price, lay_odd=c.under_back_price * (1 + L.SPREAD_OVER_UNDER),
                                    win=(c.actual_total_goals > 2.5), gols=c.actual_total_goals)))
d = pd.concat(linhas, ignore_index=True)
d["r"] = L.ret(d)
def resumo(x):
    ep = x.r.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else np.nan
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}",
                          ic95=f"{x.r.mean()-1.96*ep:+.1%} a {x.r.mean()+1.96*ep:+.1%}", lucro_120=f"{x.r.sum()*120:,.0f}"))
print("mediana e média de gols por liga (jogos com gatilho disponível):")
print(d.groupby("liga").gols.agg(["median", "mean", "size"]).round(2).to_string())
print("\nLAY no under 2,5 — por faixa de gap ofensivo:")
for liga, x in d.groupby("liga"):
    print(f"\n== {liga} ==")
    print(x.groupby(pd.cut(x.gap, [-9, 0, 0.15, 0.25, 0.30, 0.35, 0.45, 9]), observed=True).apply(resumo).to_string())
print("\nnos limiares de hoje:")
for liga, x in d.groupby("liga"):
    for lim in (0.30, 0.35):
        print(f"  {liga:<9} limiar {lim:.2f}: ", resumo(x[x.gap >= lim]).to_dict())

# == Ligue 1, limiar 0,35: prova fora da amostra e ano a ano ==
lg1 = d[(d.liga == "Ligue 1") & (d.gap >= 0.35)].copy()
print("\n== LIGUE 1, under 2,5, limiar 0,35 ==")
print("por temporada:"); print(lg1.groupby("season").apply(resumo).to_string())
print("\nfora da amostra (escolha em 20/21-22/23, conferência em 23/24-25/26):")
print(pd.DataFrame({"20/21 a 22/23": resumo(lg1[lg1.season <= 2022]), "23/24 a 25/26": resumo(lg1[lg1.season >= 2023])}).T.to_string())

# == Ligue 1: limiares acima de 0,35, por período ==
print("\n== LIGUE 1, under 2,5, limiares acima ==")
lg = d[d.liga == "Ligue 1"]
for lim in (0.35, 0.40, 0.45, 0.50, 0.55):
    tot, velho, novo = lg[lg.gap >= lim], lg[(lg.gap >= lim) & (lg.season <= 2022)], lg[(lg.gap >= lim) & (lg.season >= 2023)]
    print(f"limiar {lim:.2f} | total {len(tot):>3} ap. {tot.r.mean():+7.2%} | 20/21-22/23 {len(velho):>3} ap. {velho.r.mean():+7.2%} | 23/24-25/26 {len(novo):>3} ap. {novo.r.mean():+7.2%}")

# == Ligue 1 acima de 0,45: os extremos atrapalham? ==
print("\n== LIGUE 1, under 2,5, acima de 0,45, por faixa ==")
lg45 = d[(d.liga == "Ligue 1") & (d.gap >= 0.45)]
fx = pd.cut(lg45.gap, [0.45, 0.55, 0.7, 0.85, 9])
print(lg45.groupby(fx, observed=True).apply(resumo).to_string())
print("\nmesmas faixas, por período:")
for nome, x in (("20/21 a 22/23", lg45[lg45.season <= 2022]), ("23/24 a 25/26", lg45[lg45.season >= 2023])):
    print(f"\n{nome}"); print(x.groupby(pd.cut(x.gap, [0.45, 0.55, 0.7, 0.85, 9]), observed=True).apply(resumo).to_string())
