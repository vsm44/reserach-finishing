# xGA por goleiro (Understat) e: a Understat muda o xG dos chutes conforme o goleiro que está em campo?
import sys, glob, gzip, json, os; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
rng = np.random.default_rng(0)

# goleiro titular de cada time em cada jogo (FotMob)
gk = []
for pasta in ("la_liga", "serie_a"):
    for f in glob.glob(f"data/bruto/fotmob/{pasta}/202[0-4]/*.json.gz"):
        if f.endswith("liga.json.gz"): continue
        d = json.load(gzip.open(f)); lu = d["content"].get("lineup") or {}
        for lado in ("homeTeam", "awayTeam"):
            tm = lu.get(lado) or {}
            for s in tm.get("starters") or []:
                if s.get("positionId") == 11:
                    gk.append(dict(f_arq=os.path.basename(f), time=tm.get("id"), goleiro=s["id"], nome_goleiro=s["name"]))
gk = pd.DataFrame(gk).drop_duplicates(["f_arq", "time"])

c = pd.read_pickle("modelo_xg/dados/variaveis.pkl").dropna(subset=["xg_understat"])
# xG do modelo v7 para cada temporada, previsto sem aquela temporada (mesma liga)
partes = []
for liga, x in c.groupby("liga"):
    pen = x[x.lance == "Penalty"].xg_understat.median()
    partes.append(t.previsoes_fora_da_temporada(x, t.V7, lambda df, pen=pen: pen))
c = pd.concat(partes)
c = c.merge(gk.rename(columns={"time": "adversario"}), on=["f_arq", "adversario"], how="left")
print(f"chutes com goleiro identificado: {c.goleiro.notna().mean():.1%}")

# 1) xGA por goleiro: soma do xG da Understat dos chutes que ele enfrentou, gols sofridos
j = c.groupby(["goleiro", "nome_goleiro"]).agg(jogos=("f_arq", "nunique"), chutes=("gol", "size"), xga=("xg_understat", "sum"),
                                                gols=("gol", "sum")).reset_index()
j["xga_jogo"], j["gols_jogo"] = j.xga / j.jogos, j.gols / j.jogos
j["gols_menos_xga_jogo"] = (j.gols - j.xga) / j.jogos
print("\ngoleiros com 60+ jogos (20/21-24/25), ordenados por gols - xGA por jogo:")
print(j[j.jogos >= 60].sort_values("gols_menos_xga_jogo")[["nome_goleiro", "jogos", "xga_jogo", "gols_jogo", "gols_menos_xga_jogo"]].round(2).to_string(index=False))

# 2) o goleiro muda o xG? desvio (Understat - modelo) dos chutes, descontado o time que defende na temporada
q = c[(c.lance != "Penalty") & c.goleiro.notna()].copy()
q["res"] = q.xg_understat - q.xg_modelo
q["dfn"] = q.adversario.astype(str) + "|" + q.season.astype(str)
q["res_dt"] = q.res - q.groupby("dfn").res.transform("mean")
def metade(df, chave, minimo, rotulo, col):
    d = df[df.groupby(chave)[col].transform("size") >= minimo].copy(); d["lado"] = rng.integers(0, 2, len(d))
    m = d.groupby(chave + ["lado"])[col].mean().unstack().dropna()
    d["emb"] = rng.permutation(d[col].values)
    me = d.groupby(chave + ["lado"]).emb.mean().unstack().dropna()
    print(f"{rotulo:<52} grupos {len(m):>4}  metade prevê a outra {m[0].corr(m[1]):+.3f}  (embaralhado {me[0].corr(me[1]):+.3f})")
print("\nsobra de xG que o modelo não explica, agrupada por goleiro:")
metade(q, ["goleiro"], 300, "goleiro (300+ chutes enfrentados)", "res")
metade(q, ["goleiro", "dfn"], 150, "goleiro dentro do mesmo time-temporada (150+)", "res_dt")
# reserva x titular: no mesmo time-temporada, jogos com o goleiro mais usado x com outro
q["principal"] = q.groupby("dfn").goleiro.transform(lambda s: s.value_counts().index[0]) == q.goleiro
r = q.groupby("principal").res_dt.agg(["mean", "size"])
print(f"\nmesmo time-temporada: desvio com goleiro principal {r.loc[True, 'mean']:+.4f} ({int(r.loc[True, 'size'])} chutes)"
      f" x com outro goleiro {r.loc[False, 'mean']:+.4f} ({int(r.loc[False, 'size'])} chutes)")
