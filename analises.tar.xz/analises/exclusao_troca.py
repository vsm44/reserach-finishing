# LAY-over com três exclusões de ataque: a de hoje (xG), a do xGOT e nenhuma.
# Reconstrói as apostas do zero a partir dos sinais do motor, então o "xG" reproduz o oficial.
import sys, glob; sys.path.insert(0, "src")
import numpy as np, pandas as pd
import betedges.leagues as L
from betedges.cli import silencioso
sys.path.insert(0, "modelo_xg/analises")
from exclusao_xgot import gap_xgot     # mesma conta: (xGOT - gols)/xGOT nos 4 anteriores

linhas = []
for lg in L.LEAGUES.values():
    gaps = gap_xgot(lg.name, lg.csv_glob)
    capturas, original = [], L.completa_gols
    def espiao(c, nome, _cap=capturas, _orig=original):
        _cap.append(c.copy()); return _orig(c, nome)
    L.completa_gols = espiao
    with silencioso(True):
        L.build_league_bets(lg)
    L.completa_gols = original
    c = L.completa_gols(capturas[0], lg.name)
    c["date"] = pd.to_datetime(c.kickoff).dt.normalize()
    verm = L.build_red_card_window_table(lg.csv_glob, short_window=lg.lay_over[0])
    for lado in ("home", "away"):
        c = c.merge(verm.rename(columns={"team": f"{lado}_team", "vermelhos_janela": f"{lado}_verm"}),
                    left_on=["kickoff", f"{lado}_team"], right_on=["Date", f"{lado}_team"], how="left").drop(columns=["Date"])
        c = c.merge(gaps.rename(columns={"team": f"{lado}_team", "gap_xgot": f"{lado}_gap_xgot", "Date": "date"}),
                    on=["date", f"{lado}_team"], how="left")
    c["dfn"] = c.home_defensive_regression_applied | c.away_defensive_regression_applied
    c["atk_xg"] = c.home_regression_applied | c.away_regression_applied
    c["atk_xgot"] = ((c.home_gap_xgot >= 0.35) | (c.away_gap_xgot >= 0.35)).fillna(False)
    c["excesso"] = ((c.home_defensive_regression_applied & (c.home_verm >= L.RED_CARD_LIMIAR).fillna(False))
                    | (c.away_defensive_regression_applied & (c.away_verm >= L.RED_CARD_LIMIAR).fillna(False)))
    c = c[c.dfn & ~c.excesso].dropna(subset=["over_back_price", "under_back_price"])
    c = c[~c.season_real.isin([2019])]
    base = pd.DataFrame(dict(liga=lg.name, season=c.season_real, date=c.kickoff, home=c.home_team, away=c.away_team,
                             market_odd=c.over_back_price, lay_odd=c.over_back_price * (1 + L.SPREAD_OVER_UNDER),
                             win=(c.actual_total_goals <= 2.5), kind="LAY-over",
                             atk_xg=c.atk_xg, atk_xgot=c.atk_xgot,
                             # o maior gap dos dois times, nas duas métricas, para olhar por faixa
                             gap_xgot=c[["home_gap_xgot", "away_gap_xgot"]].max(axis=1),
                             gap_xg=c[["home_gap_ofensivo", "away_gap_ofensivo"]].max(axis=1) if "home_gap_ofensivo" in c else np.nan))
    linhas.append(base)
d = pd.concat(linhas, ignore_index=True)
d["r"] = L.ret(d)

def resumo(x):
    return pd.Series(dict(apostas=len(x), acerto=f"{x.win.mean():.1%}", roi=f"{x.r.mean():+.2%}", lucro_120=f"{x.r.sum()*120:,.0f}"))
# quatro jeitos de excluir: só xG (hoje), só xGOT, qualquer uma das duas (mais rígida),
# só quando as DUAS acusam (mais permissiva, o espelho da união das fontes), e nenhuma
VERSOES = {"hoje (exclusão por xG)": ~d.atk_xg, "exclusão por xGOT": ~d.atk_xgot,
           "exclui se qualquer uma acusa": ~(d.atk_xg | d.atk_xgot),
           "exclui só se as duas acusam": ~(d.atk_xg & d.atk_xgot),
           "sem exclusão": pd.Series(True, index=d.index),
           # cortes pelo gap de xGOT: só o miolo (0 a 0,35) e o miolo somado à exclusão de hoje
           "só o miolo do xGOT (0 a 0,35)": d.gap_xgot.between(0, 0.35),
           "miolo do xGOT + exclusão por xG": d.gap_xgot.between(0, 0.35) & ~d.atk_xg,
           "corta só o gap negativo": d.gap_xgot >= 0,
           "gap negativo fora + exclusão por xG": (d.gap_xgot >= 0) & ~d.atk_xg}
print("TOTAL (20/21 a 25/26, 3 ligas)")
print(pd.DataFrame({k: resumo(d[v]) for k, v in VERSOES.items()}).T.to_string())
print("\nPOR LIGA")
for liga, x in d.groupby("liga"):
    print(f"\n{liga}"); print(pd.DataFrame({k: resumo(x[v[x.index]]) for k, v in VERSOES.items()}).T.to_string())
print("\nPOR FAIXA DE GAP (todas as apostas com a defesa disparando, antes de qualquer exclusão)")
for col, rot in (("gap_xgot", "gap por xGOT: (xGOT - gols)/xGOT"), ("gap_xg", "gap por xG: (xG - gols)/xG")):
    if d[col].notna().sum() < 100:
        continue
    faixas = pd.cut(d[col], [-9, -0.15, 0, 0.15, 0.25, 0.35, 0.45, 9])
    print(f"\n{rot}")
    print(d.groupby(faixas, observed=True).apply(resumo).to_string())

print("\nPOR TEMPORADA")
for s, x in d.groupby("season"):
    print(f"\n{int(s)}/{int(s)+1-2000}"); print(pd.DataFrame({k: resumo(x[v[x.index]]) for k, v in VERSOES.items()}).T.to_string())
