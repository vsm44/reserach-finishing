# Concordância do gatilho do LAY-over (v7), POR JOGO e com os jogos ANTERIORES, como no motor:
#   defesa: (gols sofridos - xGA)/xGA na janela da liga >= 0,45, em qualquer um dos dois times
#   exclusão de ataque: (xG - gols)/xG nos 4 anteriores >= 0,35 (só positivo), em qualquer um dos dois
# Sem vermelhos nem odds.
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
JAN = {"Serie_A": 2, "La_liga": 3}
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
base = c[c.lance != "Penalty"].dropna(subset=["xg_understat"])
pen = c[c.lance == "Penalty"].dropna(subset=["xg_understat"]).groupby("liga").xg_understat.median()

def sinais(x, col, liga):
    j = x.groupby(["f_arq", "data", "time", "adversario"]).agg(xg=(col, "sum"), gols=("gol", "sum")).reset_index()
    sofr = j.rename(columns={"time": "adversario", "adversario": "time", "xg": "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
    j = j.merge(sofr, on=["f_arq", "time"]).sort_values("data")
    g = j.groupby("time")
    w = JAN[liga]
    xga_w = g.xga.transform(lambda s: s.rolling(w).mean().shift(1)); gs_w = g.gs.transform(lambda s: s.rolling(w).mean().shift(1))
    xg_4 = g.xg.transform(lambda s: s.rolling(4).mean().shift(1)); gl_4 = g.gols.transform(lambda s: s.rolling(4).mean().shift(1))
    j["def"] = (gs_w - xga_w) / xga_w >= 0.45
    j["atq"] = ((xg_4 - gl_4) / xg_4 >= 0.35) & (xg_4 > gl_4)
    j["ok"] = xga_w.notna() & xg_4.notna()
    m = j.groupby("f_arq").agg(defesa=("def", "any"), ataque=("atq", "any"), ok=("ok", "all"))
    m = m[m.ok]
    return m.defesa, m.defesa & ~m.ataque

def mede(te, nome):
    for liga, x in te.groupby("liga"):
        x = x.dropna(subset=["xg_understat"])
        (du, du2), (dm, dm2) = sinais(x, "xg_understat", liga), sinais(x, "xg_modelo", liga)
        for rot, a, b in (("só defesa", du, dm), ("defesa sem exclusão de ataque", du2, dm2)):
            a, b = a.align(b, join="inner")
            print(f"{nome:<22} {liga:<8} {rot:<31} jogos {len(a):>5} | U {int(a.sum()):>4}  M {int(b.sum()):>4}  os dois {int((a&b).sum()):>4} | concordância {(a&b).sum()/(a|b).sum():.1%}")

m = t.treina(base[base.season <= 2023], t.V7)
te = c[c.season == 2024].copy(); te["xg_modelo"] = t.preve(m, te, t.V7, te.liga.map(pen)); mede(te, "tempo (24/25)")
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    m = t.treina(base[base.liga == a], t.V7)
    te = c[c.liga == b].copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen[a]); mede(te, f"liga nunca vista")

# == POR QUE DISCORDA: nos jogos em que só um disparou, quão perto do limiar estava a Understat e qual filtro mudou ==
def detalhe(x, col, liga):
    j = x.groupby(["f_arq", "data", "time", "adversario"]).agg(xg=(col, "sum"), gols=("gol", "sum")).reset_index()
    sofr = j.rename(columns={"time": "adversario", "adversario": "time", "xg": "xga", "gols": "gs"})[["f_arq", "time", "xga", "gs"]]
    j = j.merge(sofr, on=["f_arq", "time"]).sort_values("data"); g = j.groupby("time"); w = JAN[liga]
    xga_w = g.xga.transform(lambda s: s.rolling(w).mean().shift(1)); gs_w = g.gs.transform(lambda s: s.rolling(w).mean().shift(1))
    xg_4 = g.xg.transform(lambda s: s.rolling(4).mean().shift(1)); gl_4 = g.gols.transform(lambda s: s.rolling(4).mean().shift(1))
    j["gdef"] = (gs_w - xga_w) / xga_w; j["gatq"] = np.where(xg_4 > gl_4, (xg_4 - gl_4) / xg_4, -1)
    return j.groupby("f_arq").agg(gdef=("gdef", "max"), gatq=("gatq", "max"))
print()
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    m = t.treina(base[base.liga == a], t.V7)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, t.V7, pen[a])
    U, M = detalhe(te, "xg_understat", b), detalhe(te, "xg_modelo", b)
    k = U.join(M, lsuffix="_u", rsuffix="_m").dropna()
    k["du"] = (k.gdef_u >= 0.45) & (k.gatq_u < 0.35); k["dm"] = (k.gdef_m >= 0.45) & (k.gatq_m < 0.35)
    for rot, s in (("só Understat disparou", k.du & ~k.dm), ("só modelo disparou", ~k.du & k.dm)):
        x = k[s]
        mud_def = ((x.gdef_u >= 0.45) != (x.gdef_m >= 0.45)).mean()
        mud_atq = ((x.gatq_u >= 0.35) != (x.gatq_m >= 0.35)).mean()
        print(f"{b:<8} {rot:<22} {len(x):>3} jogos | defesa mudou de lado em {mud_def:.0%}, exclusão de ataque em {mud_atq:.0%}"
              f" | gap defesa Understat mediano {x.gdef_u.median():.2f} (modelo {x.gdef_m.median():.2f})")
