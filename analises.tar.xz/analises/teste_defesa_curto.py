# A Understat dá xG diferente contra uma defesa conforme o que ela sofreu nos últimos jogos?
# Compara dentro do mesmo time e temporada, para tirar o efeito de "defesa boa o ano todo"
import sys
import numpy as np, pandas as pd
c = pd.read_pickle(sys.argv[1])
c["date"] = pd.to_datetime(c.date)
for col in ("h_goals", "a_goals"): c[col] = c[col].astype(int)

# Série de jogos por time: gols sofridos, xG sofrido e média dos 3 jogos ANTERIORES
jogos = c.groupby("match_id").agg(date=("date", "first"), h=("h_team", "first"), a=("a_team", "first"),
                                   hg=("h_goals", "first"), ag=("a_goals", "first"), season=("season", "first"),
                                   liga=("liga", "first"))
xg_lado = c.groupby(["match_id", "h_a"]).xG.sum().unstack(fill_value=0).add_prefix("xg_")
jogos = jogos.join(xg_lado)
serie = pd.concat([
    pd.DataFrame(dict(match_id=jogos.index, date=jogos.date, season=jogos.season, time=jogos.h, sofridos=jogos.ag, xga=jogos["xg_a"])),
    pd.DataFrame(dict(match_id=jogos.index, date=jogos.date, season=jogos.season, time=jogos.a, sofridos=jogos.hg, xga=jogos["xg_h"])),
]).sort_values("date").reset_index(drop=True)
g = serie.groupby(["time", "season"])
for col in ("sofridos", "xga"):
    serie[f"{col}_3"] = g[col].transform(lambda s: s.rolling(3).mean().shift(1))
serie["sorte_3"] = serie.sofridos_3 - serie.xga_3   # sofreu mais que o xG recente = azar da defesa

# Célula fina, igual aos testes 2 e 3
q = c[c.situation != "Penalty"].copy()
dx, dy = (1 - q.X) * 105, (q.Y - 0.5) * 68
q["dist"], q["ang"] = np.hypot(dx, dy), np.degrees(np.abs(np.arctan2(dy, dx)))
q["cel"] = (pd.cut(q.dist, list(range(0, 21)) + list(range(22, 41, 2)) + [200]).astype(str) + "|"
            + pd.cut(q.ang, range(0, 95, 5), include_lowest=True).astype(str) + "|"
            + q.situation + "|" + q.shotType + "|" + q.lastAction)
q = q[q.groupby("cel").xG.transform("size") >= 5].copy()
q["res"] = q.xG - q.groupby("cel").xG.transform("mean")

# Desvio médio por jogo, do lado que defende, descontado o nível do time na temporada
por_jogo = q.groupby(["match_id", "time_defesa"]).agg(res=("res", "mean"), n=("res", "size")).reset_index()
por_jogo = por_jogo.merge(serie, left_on=["match_id", "time_defesa"], right_on=["match_id", "time"]).dropna(subset=["sofridos_3"])
for col in ("res", "sofridos_3", "xga_3", "sorte_3"):
    por_jogo[f"{col}_dt"] = por_jogo[col] - por_jogo.groupby(["time", "season"])[col].transform("mean")

print(f"jogos-defesa: {len(por_jogo)}")
print("correlação do desvio de xG contra a defesa NESTE jogo com os 3 jogos anteriores dela (dentro do time-temporada):")
for col, nome in (("sofridos_3_dt", "gols sofridos"), ("xga_3_dt", "xG sofrido"), ("sorte_3_dt", "gols sofridos - xG sofrido")):
    r = por_jogo.res_dt.corr(por_jogo[col])
    n = len(por_jogo); ep = 1 / np.sqrt(n - 3)
    print(f"  {nome:<28} r = {r:+.3f}   (faixa de acaso ~ ±{1.96*ep:.3f})")
# Referência: o mesmo jogo, com a defesa do PRÓPRIO jogo (sabe o resultado) — para comparar tamanho
rj = por_jogo.merge(serie[["match_id", "time", "sofridos"]].rename(columns={"sofridos": "sof_jogo"}), on=["match_id", "time"])
rj["sof_jogo_dt"] = rj.sof_jogo - rj.groupby(["time", "season"]).sof_jogo.transform("mean")
print(f"  referência, gols sofridos no PRÓPRIO jogo   r = {rj.res_dt.corr(rj.sof_jogo_dt):+.3f}")

# O +0,29 vem de quê? Dentro da mesma célula, chute que virou gol tem xG maior que chute que não virou?
print("\ndesvio médio do xG dentro da célula, por resultado do chute:")
print(q.groupby("result").res.agg(["mean", "size"]).round(4).to_string())
# Sem os gols: o desvio dos chutes que NÃO viraram gol ainda acompanha os gols sofridos no jogo?
sem = q[q.result != "Goal"].groupby(["match_id", "time_defesa"]).res.mean().rename("res_sem_gol").reset_index()
rj = rj.merge(sem, on=["match_id", "time_defesa"])
rj["rsg_dt"] = rj.res_sem_gol - rj.groupby(["time", "season"]).res_sem_gol.transform("mean")
print(f"\nsó chutes que não viraram gol x gols sofridos no próprio jogo: r = {rj.rsg_dt.corr(rj.sof_jogo_dt):+.3f}")

# Desconta ao mesmo tempo o nível do time que ATACA e do que DEFENDE na temporada (médias alternadas)
print("\n== descontando ataque e defesa por temporada ==")
q["atk"] = q.time_chute + "|" + q.season.astype(str)
q["dfn"] = q.time_defesa + "|" + q.season.astype(str)
r = q.res.copy()
for _ in range(20):
    r = r - r.groupby(q.atk).transform("mean")
    r = r - r.groupby(q.dfn).transform("mean")
q["res2"] = r
print(f"desvio que sobra: antes {q.res.std():.4f}, depois {q.res2.std():.4f}")
for nome, sel in (("todos os chutes", q), ("só os que não viraram gol", q[q.result != "Goal"])):
    m = sel.groupby(["match_id", "time_defesa"]).res2.mean().rename("r2").reset_index()
    m = m.merge(rj[["match_id", "time_defesa", "sof_jogo_dt"]], on=["match_id", "time_defesa"])
    print(f"  {nome:<28} x gols sofridos no jogo: r = {m.r2.corr(m.sof_jogo_dt):+.3f}")

print("\n== por temporada, só chutes que não viraram gol ==")
sel = q[q.result != "Goal"]
m1 = sel.groupby(["match_id", "time_defesa"]).agg(r1=("res", "mean"), r2=("res2", "mean")).reset_index()
m1 = m1.merge(rj[["match_id", "time_defesa", "time", "season", "sof_jogo"]], on=["match_id", "time_defesa"]).merge(q.groupby("match_id").liga.first().reset_index(), on="match_id")
m1["r1_dt"] = m1.r1 - m1.groupby(["time", "season"]).r1.transform("mean")
m1["sof_dt"] = m1.sof_jogo - m1.groupby(["time", "season"]).sof_jogo.transform("mean")
for (lg, s), g in m1.groupby(["liga", "season"]):
    a, b = g.r1_dt.corr(g.sof_dt), g.r2.corr(g.sof_dt)
    print(f"  {lg:<8} {s}/{s+1-2000}  sem descontar {a:+.3f}  descontando {b:+.3f}  queda {1-b/a:+.0%}  (n={len(g)})")

# == PLACAR NO MOMENTO DO CHUTE (visão de quem chuta) ==
# gol conta para o lado do chute; gol contra conta para o outro lado; ordem pelo id do chute
c["id_n"] = c.id.astype(int)
c = c.sort_values(["match_id", "id_n"])
c["gol_h"] = ((c.result == "Goal") & (c.h_a == "h")) | ((c.result == "OwnGoal") & (c.h_a == "a"))
c["gol_a"] = ((c.result == "Goal") & (c.h_a == "a")) | ((c.result == "OwnGoal") & (c.h_a == "h"))
gm = c.groupby("match_id")
c["h_antes"] = gm.gol_h.cumsum() - c.gol_h
c["a_antes"] = gm.gol_a.cumsum() - c.gol_a
c["saldo"] = (c.h_antes - c.a_antes).where(c.h_a == "h", c.a_antes - c.h_antes)
q = q.join(c.set_index(c.index)[["saldo"]])
q["placar"] = pd.cut(q.saldo, [-9, -3, -2, -1, 0, 1, 2, 9], labels=["perde 3+", "perde 2", "perde 1", "empate", "ganha 1", "ganha 2", "ganha 3+"])
print("\n== placar no momento do chute: desvio do xG já descontando lugar, tipo e times ==")
t = q[q.result != "OwnGoal"].groupby(["season", "placar"], observed=True).res2.mean().unstack().round(4)
print(t.to_string())
print("\ntodas as temporadas:", q.groupby("placar", observed=True).res2.agg(["mean", "size"]).round(4).to_dict("index"))
print("\n== minuto (15 em 15) ==")
print(q.groupby(pd.cut(q.minute, [0, 15, 30, 45, 60, 75, 90, 130]), observed=True).res2.mean().round(4).to_string())
