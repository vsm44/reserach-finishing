# Concordância dos gatilhos por ANO DO CALENDÁRIO (como o item 1 do financeiro), v7, liga nunca vista
import sys; sys.path.insert(0, "modelo_xg")
import pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
VERSAO = sys.argv[1] if len(sys.argv) > 1 else "V7"   # V7, V9A ou V9B
COLS = getattr(t, VERSAO)
print("versão:", VERSAO)
todos = []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    base = c[(c.liga == a) & (c.lance != "Penalty")].dropna(subset=["xg_understat"])
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(base, COLS)
    te = c[c.liga == b].dropna(subset=["xg_understat"]).copy(); te["xg_modelo"] = t.preve(m, te, COLS, pen)
    j = t.tabela_jogo(te, "xg_modelo")
    gu, gm = t.gatilhos(j, "xg_u", b), t.gatilhos(j, "xg_soma", b)
    gu, gm = gu.align(gm, join="inner")
    ano = j.groupby("f_arq").data.first().dt.year.reindex(gu.index)
    todos.append(pd.concat([gu.add_suffix("|u"), gm.add_suffix("|m")], axis=1).assign(ano=ano.values, liga=b))
d = pd.concat(todos)
def tabela(x):
    l = {}
    for k in ("LAY-over defesa", "LAY-over completo", "LAY-under"):
        u, m = x[f"{k}|u"], x[f"{k}|m"]
        l[k] = f"{(u&m).sum()/max((u|m).sum(),1):.1%} ({int(u.sum())}/{int(m.sum())})"
    return pd.Series(l)
print("concordância (disparos Understat / disparos modelo)\n")
print("AS DUAS LIGAS"); r = d.groupby("ano").apply(tabela); r.loc["TOTAL"] = tabela(d); print(r.to_string())
for liga, x in d.groupby("liga"):
    print(f"\n{liga}"); r = x.groupby("ano").apply(tabela); r.loc["TOTAL"] = tabela(x); print(r.to_string())
