# Jogos de time em que o modelo (v7, liga nunca vista) mais se afasta da Understat: o que eles têm em comum?
# Inclui o xGOT do FotMob (que a Understat não tem) para ver se ele explica o erro.
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl").dropna(subset=["xg_understat"])
partes = []
for a, b in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    tr = c[(c.liga == a) & (c.lance != "Penalty")]
    pen = c[(c.liga == a) & (c.lance == "Penalty")].xg_understat.median()
    m = t.treina(tr, t.V7)
    te = c[c.liga == b].copy(); te["nosso"] = t.preve(m, te, t.V7, pen)
    partes.append(te)
x = pd.concat(partes)
x["_cab"] = x.parte == "Header"
x["_parada"] = x.lance.isin(["FromCorner", "SetPiece", "FreeKick", "ThrowInSetPiece"])
x["_contra"] = x.lance == "FastBreak"
x["_perto"] = x.distancia < 11
j = x.groupby(["liga", "f_arq", "time"]).agg(
    xg_u=("xg_understat", "sum"), xg_m=("nosso", "sum"), xgot=("xgot", "sum"), chutes=("gol", "size"),
    gols=("gol", "sum"), no_alvo=("no_alvo", "sum"), bloqueados=("bloqueado", "sum"), cabecadas=("_cab", "sum"),
    bola_parada=("_parada", "sum"), contra_ataque=("_contra", "sum"), perto=("_perto", "sum"),
    gc_marcadas=("gc_marcada", "sum"), penaltis=("lance", lambda s: (s == "Penalty").sum()),
    dist_media=("distancia", "mean")).reset_index()
j["erro"] = j.xg_m - j.xg_u
j["erro_rel"] = j.erro.abs() / j.xg_u.clip(lower=0.3)
j["xgot_menos_xg"] = j.xgot - j.xg_u
j["gols_menos_xgot"] = j.gols - j.xgot
corte = j.erro_rel.quantile(0.9)
j["grupo"] = np.where(j.erro_rel >= corte, "10% que mais erram", "resto")
cols = ["xg_u", "xg_m", "erro", "chutes", "gols", "no_alvo", "bloqueados", "cabecadas", "bola_parada",
        "contra_ataque", "perto", "gc_marcadas", "penaltis", "dist_media", "xgot", "xgot_menos_xg", "gols_menos_xgot"]
print(f"jogos de time: {len(j)} | corte do erro relativo: {corte:.1%}\n")
print(j.groupby("grupo")[cols].mean().T.round(2).to_string())
print("\nerro médio do modelo por faixa de (xGOT - xG da Understat) do jogo:")
print(j.groupby(pd.qcut(j.xgot_menos_xg, 5), observed=True).agg(jogos=("erro", "size"), erro_medio=("erro", "mean"),
      erro_rel=("erro_rel", "mean"), xg_u=("xg_u", "mean")).round(3).to_string())
print("\ncorrelação do erro do modelo com:")
for col in ("xgot_menos_xg", "gols_menos_xgot", "xgot", "xg_u", "gc_marcadas", "cabecadas", "chutes"):
    print(f"  {col:<16} {j.erro.corr(j[col]):+.3f}")
