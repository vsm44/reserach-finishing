# v5, prova da liga nunca vista: onde o modelo erra e qual o teto da concordância
import sys; sys.path.insert(0, "modelo_xg")
import numpy as np, pandas as pd
import treina_avalia as t
rng = np.random.default_rng(0)
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl")
base = c[c.lance != "Penalty"].dropna(subset=["xg_understat"])
pen = c[c.lance == "Penalty"].dropna(subset=["xg_understat"]).groupby("liga").xg_understat.median()
partes = []
for liga_tr, liga_te in (("La_liga", "Serie_A"), ("Serie_A", "La_liga")):
    m = t.treina(base[base.liga == liga_tr], t.V5)
    te = c[c.liga == liga_te].dropna(subset=["xg_understat"]).copy()
    te["xg_modelo"] = t.preve(m, te, t.V5, pen[liga_tr])
    partes.append(te)
te = pd.concat(partes)
te["erro"] = te.xg_modelo - te.xg_understat

print("== 1. ONDE ERRA (soma do erro absoluto: parcela do total) ==")
te["dist_f"] = pd.cut(te.distancia, [0, 6, 11, 16, 25, 120])
te["gc_f"] = pd.cut(te.grande_chance, [-0.01, 0, 0.5, 1])
tot = te.erro.abs().sum()
for col in ("lance", "parte", "dist_f", "gc_f", "gol"):
    g = te.groupby(col, observed=True).agg(chutes=("erro", "size"), erro_medio=("erro", lambda s: s.abs().mean()),
                                            vies=("erro", "mean"), xg_u=("xg_understat", "mean"))
    g["parcela_do_erro"] = te.groupby(col, observed=True).erro.apply(lambda s: s.abs().sum()) / tot
    print(f"\n{col}\n" + g.round(3).to_string())

print("\n== 2. TETO: concordância com erros sorteados do mesmo tamanho, e menores ==")
for liga, x in te.groupby("liga"):
    ju, jm = t.por_jogo(x, "xg_understat"), t.por_jogo(x, "xg_modelo")
    jm = jm.set_index(["f_arq", "time"]).loc[list(zip(ju.f_arq, ju.time))].reset_index()
    razao = (jm.xga.values + 0.05) / (ju.xga.values + 0.05)   # erro relativo de cada jogo
    wu = t.janela(ju, liga)
    real = t.janela(jm.assign(data=ju.data.values), liga)
    du, dm = wu.dispara.values, real.dispara.values
    print(f"\n{liga}: real {(du&dm).sum()/(du|dm).sum():.1%}  | correlação por jogo {np.corrcoef(ju.xga, jm.xga)[0,1]:.3f}")
    for fator in (1.0, 0.75, 0.5, 0.25):
        conc = []
        for _ in range(20):
            r = np.exp(np.log(rng.permutation(razao)) * fator)
            sim = ju.copy(); sim["xga"] = (ju.xga.values + 0.05) * r - 0.05
            ws = t.janela(sim, liga); ds = ws.dispara.values
            conc.append((du & ds).sum() / (du | ds).sum())
        print(f"  erro {fator:.0%} do atual: concordância {np.mean(conc):.1%}  (correlação por jogo ~{np.corrcoef(ju.xga, sim.xga)[0,1]:.3f})")
