# O analista marca grande chance com mais facilidade quando o chute vira gol?
# Compara, na mesma distância e parte do corpo, a parcela de grande chance de gols x chutes perdidos,
# e o xG da Understat dos chutes marcados como grande chance, gols x perdidos.
import numpy as np, pandas as pd
c = pd.read_pickle("modelo_xg/dados/variaveis.pkl").dropna(subset=["xg_understat"])
c = c[c.lance != "Penalty"].copy()
c["dist"] = pd.cut(c.distancia, [0, 6, 9, 12, 16, 20, 120])
c["corpo"] = np.where(c.parte == "Header", "cabeça", "pé")
c["resultado"] = np.where(c.gol == 1, "gol", "não gol")
t = c.groupby(["corpo", "dist", "resultado"], observed=True).agg(chutes=("gol", "size"), parcela_gc=("grande_chance", "mean"),
                                                                  xg_understat=("xg_understat", "mean")).unstack("resultado")
print("parcela média de grande chance (quanto do chute é marcado) e xG médio da Understat, por resultado:")
print(t.round(3).to_string())
m = c[c.gc_marcada == 1].groupby(["corpo", "dist", "resultado"], observed=True).agg(chutes=("gol", "size"), xg_understat=("xg_understat", "mean")).unstack("resultado")
print("\nsó chutes MARCADOS como grande chance: xG médio da Understat, gol x não gol")
print(m.round(3).to_string())
