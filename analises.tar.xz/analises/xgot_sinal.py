# O que vem do xGOT nos jogos ANTERIORES diz algo sobre os gols do próximo jogo?
# Todos os jogos das 3 ligas (20/21 em diante), sem filtro de aposta. Só mede: não escolhe limiar.
import numpy as np, pandas as pd
d = pd.read_csv("modelo_xg/dados/xgot_por_jogo.csv")
d = d[(d.liga != "Portugal") & (d.temporada >= 2020)].copy()
d["data"] = pd.to_datetime(d.data)
# uma linha por time em cada jogo, com o que ele fez e o que sofreu
lados = []
for lado, outro in (("mandante", "visitante"), ("visitante", "mandante")):
    lados.append(pd.DataFrame(dict(liga=d.liga, temporada=d.temporada, data=d.data, match_id=d.match_id, mando=lado,
                                   time=d[lado], adversario=d[outro],
                                   gols=d[f"gols_{lado}"], gols_sofridos=d[f"gols_{outro}"],
                                   xg=d[f"xg_{lado}"], xga=d[f"xg_{outro}"],
                                   xgot=d[f"xgot_{lado}"], xgot_sofrido=d[f"xgot_{outro}"])))
t = pd.concat(lados).dropna(subset=["xg", "xgot"]).sort_values("data")
t["total_gols"] = t.gols + t.gols_sofridos
# as quatro contas do xGOT, no jogo
t["finalizacao"] = t.xgot - t.xg                          # o time finalizou acima do que as chances valiam
t["goleiro_adv"] = t.xgot - t.gols                        # o goleiro adversário segurou
t["finalizacao_adv"] = t.xgot_sofrido - t.xga             # o adversário finalizou bem contra ele
t["goleiro_proprio"] = t.xgot_sofrido - t.gols_sofridos   # o goleiro dele segurou
g = t.groupby("time")
ant = lambda s, n=4: s.rolling(n).mean().shift(1)
for col in ("xg", "xga", "xgot", "xgot_sofrido", "gols", "gols_sofridos", "finalizacao", "goleiro_adv",
            "finalizacao_adv", "goleiro_proprio"):
    t[f"{col}_ant"] = g[col].transform(ant)
t = t.dropna(subset=["xg_ant"])
print(f"jogos de time: {len(t)}\n")
print("correlação das médias dos 4 jogos ANTERIORES com o que acontece NO jogo seguinte:")
print(f"{'medida anterior':<36} {'gols do time':>13} {'gols sofridos':>14} {'total de gols':>14}")
for col, rot in (("xg_ant", "xG criado"), ("xgot_ant", "xGOT criado"), ("gols_ant", "gols marcados"),
                 ("xga_ant", "xG sofrido"), ("xgot_sofrido_ant", "xGOT sofrido"), ("gols_sofridos_ant", "gols sofridos"),
                 ("finalizacao_ant", "finalização (xGOT - xG)"), ("goleiro_adv_ant", "goleiro adv. (xGOT - gols)"),
                 ("finalizacao_adv_ant", "finalização do adversário"), ("goleiro_proprio_ant", "goleiro próprio")):
    print(f"{rot:<36} {t[col].corr(t.gols):>12.3f} {t[col].corr(t.gols_sofridos):>14.3f} {t[col].corr(t.total_gols):>14.3f}")
print("\ngols do jogo seguinte, por faixa da medida anterior:")
for col, rot in (("finalizacao_ant", "finalização do time (xGOT - xG)"),
                 ("goleiro_proprio_ant", "goleiro próprio (xGOT sofrido - gols sofridos)"),
                 ("finalizacao_adv_ant", "finalização do adversário (xGOT sofrido - xGA)"),
                 ("goleiro_adv_ant", "goleiro adversário (xGOT - gols do time)"),
                 ("xgot_sofrido_ant", "xGOT sofrido")):
    q = t.groupby(pd.qcut(t[col], 5, duplicates="drop"), observed=True).agg(
        jogos=("total_gols", "size"), total_gols=("total_gols", "mean"),
        ate_2_gols=("total_gols", lambda s: (s <= 2).mean()),      # o que o LAY-over ganha
        dois_ou_mais=("total_gols", lambda s: (s >= 2).mean()))    # o que o LAY-under ganha
    print(f"\n{rot}\n" + q.round(3).to_string())
