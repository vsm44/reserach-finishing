"""Monta as variáveis de cada chute SÓ com dados do FotMob (o que existe em Portugal).

Para cada chute (sem gol contra), de La Liga e Serie A 20/21 a 24/25:
  lugar        x, y, distância e ângulo de visão do gol
  tipo         parte do corpo e tipo de lance do FotMob
  placar       saldo de quem chuta no momento, com teto em 2
  minuto e mando
  quem chuta   chutes e gols ANTERIORES do jogador, puxados para a média da liga
               quando a amostra é pequena
  cabeça       parcela de cabeçadas e conversão de cabeça ANTERIORES do jogador
  times        média móvel dos jogos ANTERIORES do time que chuta e do que defende
               (atravessa temporadas): gols, chutes, cabeçadas, escanteios e
               cruzamentos a favor e contra, e % de duelos aéreos ganhos
  do lance     no alvo, bloqueado, trave, onde cruzou a linha do gol (y, altura)
  escalação    força dos titulares no jogo, jogador por jogador (ver escalacao.py)
  grande chance  parcela de grande chance do chute, pelas estatísticas do jogador no jogo,
               e a marcação chute a chute (gc_marcada): os chutes de maior qualidade do
               jogador recebem as grandes chances que ele perdeu; os melhores gols do
               time recebem as convertidas
  do jogo      grandes chances (marcação Opta), grandes chances perdidas, chutes
               na área, cruzamentos e escanteios do time naquele jogo
Nos HISTÓRICOS nada do próprio jogo entra. Os fatos do lance e do jogo entram de
propósito (decisão do usuário, 14/09): o xG de um jogo é calculado depois dele e a
estratégia só usa jogos anteriores, então não vaza para a aposta.
O alvo (xG da Understat) vem do pareamento, em modelo_xg/dados/chutes_pareados.pkl.

Uso (da raiz do projeto):
  python modelo_xg/variaveis.py
Grava modelo_xg/dados/variaveis.pkl.
"""
import glob
import gzip
import json
import os

import numpy as np
import pandas as pd

from escalacao import forca_escalacao, jogadores_do_jogo

LIGAS = {"la_liga": "La_liga", "serie_a": "Serie_A"}
TEMPORADAS = range(2020, 2025)
SAIDA = "modelo_xg/dados/variaveis.pkl"
K_JOGADOR = 30        # chutes "fictícios" na média da liga, para quem tem pouca amostra
MEIA_VIDA_TIME = 10   # jogos; peso da média móvel dos times
ORDEM_TEMPO = {"FirstHalf": 0, "SecondHalf": 1, "FirstHalfExtra": 2, "SecondHalfExtra": 3}


def ler(caminho):
    with gzip.open(caminho) as f:
        return json.load(f)


def chutes_do_jogo(arq, liga, ano):
    # Todos os chutes do jogo em ordem, com o placar ANTES de cada um
    d = ler(arq)
    jogadores = jogadores_do_jogo(d, arq, pd.Timestamp(d["general"]["matchTimeUTC"]).tz_localize(None), ano)
    g = d["general"]
    casa, fora = g["homeTeam"]["id"], g["awayTeam"]["id"]
    data = pd.Timestamp(g["matchTimeUTC"]).tz_localize(None)
    shots = sorted((d["content"].get("shotmap") or {}).get("shots") or [],
                   key=lambda s: (ORDEM_TEMPO.get(s["period"], 9), s["min"], s["minAdded"] or 0, s["id"]))
    gols = {casa: 0, fora: 0}
    linhas = []
    for s in shots:
        time = s["teamId"]
        adv = fora if time == casa else casa
        if not s["isOwnGoal"]:
            linhas.append(dict(
                liga=liga, season=ano, f_arq=os.path.basename(arq), data=data, f_id=s["id"],
                time=time, adversario=adv, mandante=int(time == casa), jogador=s["playerId"],
                x=s["x"], y=s["y"], parte=s["shotType"], lance=s["situation"],
                minuto=s["min"] + (s["minAdded"] or 0),
                saldo=int(np.clip(gols[time] - gols[adv], -2, 2)),
                gol=int(s["eventType"] == "Goal"),
                # fatos do próprio lance (depois do chute)
                no_alvo=int(bool(s["isOnTarget"])), bloqueado=int(bool(s["isBlocked"])),
                trave=int(s["eventType"] == "Post"),
                gol_y=s.get("goalCrossedY"), gol_z=s.get("goalCrossedZ"),
                # xG e xGOT da Opta do chute: guardados para TESTE (a Understat não tem xGOT)
                xg_opta=s.get("expectedGoals"), xgot=s.get("expectedGoalsOnTarget")))
        # gol conta depois do chute; gol contra conta para o outro time
        if s["eventType"] == "Goal":
            gols[adv if s["isOwnGoal"] else time] += 1
    jogo = dict(f_arq=os.path.basename(arq), data=data, casa=casa, fora=fora,
                gols_casa=gols[casa], gols_fora=gols[fora],
                chutes_casa=sum(s["teamId"] == casa and not s["isOwnGoal"] for s in shots),
                chutes_fora=sum(s["teamId"] == fora and not s["isOwnGoal"] for s in shots),
                cab_casa=sum(s["teamId"] == casa and s["shotType"] == "Header" for s in shots),
                cab_fora=sum(s["teamId"] == fora and s["shotType"] == "Header" for s in shots))
    jogo.update(estatisticas(d))
    # Grande chance quase chute a chute: chute que não virou gol recebe a parcela de grandes
    # chances perdidas do jogador no jogo; gol recebe a parcela de grandes chances convertidas
    # do time. A Opta conta PÊNALTI como grande chance (medido: nos jogos com pênalti convertido,
    # as convertidas passam os gols sem pênalti em 0,84 por jogo), então os pênaltis saem das
    # contagens antes de distribuir: perdidos do cobrador, convertidos do time. Pênalti não
    # passa pelo modelo, então fica com parcela 0.
    perdidas = {}
    for p in (d["content"].get("playerStats") or {}).values():
        bc, pen_perd = 0, 0
        for grp in p.get("stats") or []:
            for v in (grp.get("stats") or {}).values():
                if v.get("key") == "big_chance_missed_title":
                    bc = (v.get("stat") or {}).get("value") or 0
                elif v.get("key") == "missed_penalty":
                    pen_perd = (v.get("stat") or {}).get("value") or 0
        perdidas[p["id"]] = max(np.nan_to_num(bc) - np.nan_to_num(pen_perd), 0)
    nao_gol, gols_sem_pen, pen_gol = {}, {}, {}
    for l in linhas:
        if l["lance"] == "Penalty":
            pen_gol[l["time"]] = pen_gol.get(l["time"], 0) + l["gol"]
        elif l["gol"]:
            gols_sem_pen[l["time"]] = gols_sem_pen.get(l["time"], 0) + 1
        else:
            nao_gol[l["jogador"]] = nao_gol.get(l["jogador"], 0) + 1
    convertidas = {}
    for time in {l["time"] for l in linhas}:
        lado = "casa" if time == casa else "fora"
        s = np.nan_to_num((jogo.get(f"grandes_{lado}") or 0) - (jogo.get(f"grandes_perdidas_{lado}") or 0))
        convertidas[time] = max(s - pen_gol.get(time, 0), 0)
    for l in linhas:
        if l["lance"] == "Penalty":
            l["grande_chance"] = 0.0
        elif l["gol"]:
            l["grande_chance"] = min(convertidas[l["time"]] / max(gols_sem_pen.get(l["time"], 0), 1), 1.0)
        else:
            l["grande_chance"] = min(perdidas.get(l["jogador"], 0) / nao_gol[l["jogador"]], 1.0)
    marca_grandes_chances(linhas, perdidas, convertidas)
    # Pistas de cabeçada disputada (a Understat separa "Aerial" de "Cross"; o FotMob não):
    # duelos aéreos disputados e ganhos por quem chutou no jogo, e cortes de cabeça do time que defende
    aereo, cortes_cab = {}, {}
    for p in (d["content"].get("playerStats") or {}).values():
        for grp in p.get("stats") or []:
            for v in (grp.get("stats") or {}).values():
                st = v.get("stat") or {}
                if v.get("key") == "aerials_won":
                    aereo[p["id"]] = (st.get("value") or 0, st.get("total") or 0)
                elif v.get("key") == "headed_clearance":
                    cortes_cab[p.get("teamId")] = cortes_cab.get(p.get("teamId"), 0) + (st.get("value") or 0)
    for l in linhas:
        g_, tot = aereo.get(l["jogador"], (0, 0))
        l["jog_aereos_ganhos"], l["jog_aereos_disputados"] = g_, tot
        l["adv_cortes_cabeca"] = cortes_cab.get(l["adversario"], 0)
    # placar oficial do jogo (conta gol contra), para os gatilhos usarem os mesmos gols da estratégia
    placar = {casa: d["header"]["teams"][0].get("score"), fora: d["header"]["teams"][1].get("score")}
    for l in linhas:
        l["gols_time_jogo"] = placar[l["time"]]
    return linhas, jogo, jogadores


def qualidade(l):
    # Ordem de qualidade do chute só pela geometria e pelo lance: ângulo de visão do gol
    # por distância, cabeçada e chute bloqueado valem menos. Serve só para escolher QUAL
    # chute foi a grande chance, não entra como xG.
    dx, dy = 105 - l["x"], l["y"] - 34
    dist = max(np.hypot(dx, dy), 0.5)
    ang = abs(np.degrees(np.arctan2(7.32 * dx, dx**2 + dy**2 - (7.32 / 2) ** 2)))
    return ang / (dist + 1) * (0.6 if l["parte"] == "Header" else 1.0) * (0.5 if l["bloqueado"] else 1.0)


def marca_grandes_chances(linhas, perdidas, convertidas):
    # Grande chance marcada chute a chute: se o jogador perdeu k grandes chances (sem pênalti),
    # marca os k chutes dele sem gol de maior qualidade; se o time converteu s grandes chances
    # (sem pênalti), marca os s gols dele (sem pênalti) de maior qualidade
    for l in linhas:
        l["gc_marcada"] = 0
    por_jogador = {}
    for l in linhas:
        if not l["gol"] and l["lance"] != "Penalty":
            por_jogador.setdefault(l["jogador"], []).append(l)
    for jogador, ls in por_jogador.items():
        for l in sorted(ls, key=qualidade, reverse=True)[:int(perdidas.get(jogador, 0))]:
            l["gc_marcada"] = 1
    for time, s in convertidas.items():
        gols_time = [l for l in linhas if l["time"] == time and l["gol"] and l["lance"] != "Penalty"]
        for l in sorted(gols_time, key=qualidade, reverse=True)[:int(s)]:
            l["gc_marcada"] = 1


def _numero(v):
    # "4 (15%)" -> (4, 0,15); 8 -> (8, None)
    if isinstance(v, str) and "(" in v:
        n, pct = v.split("(")
        return int(n), float(pct.strip(" %)")) / 100
    return (int(v) if v is not None else None), None


def estatisticas(d):
    # Escanteios, cruzamentos (total e certos) e duelos aéreos de cada lado, do jogo inteiro
    achado = {}
    try:
        grupos = d["content"]["stats"]["Periods"]["All"]["stats"]
    except (KeyError, TypeError):
        grupos = []
    for grp in grupos:
        for s in grp.get("stats") or []:
            if s.get("key") in ("corners", "accurate_crosses", "aerials_won", "big_chance", "big_chance_missed_title",
                                "shots_inside_box") and len(s.get("stats") or []) == 2:
                achado[s["key"]] = [_numero(v) for v in s["stats"]]
    out = {}
    for i, lado in enumerate(("casa", "fora")):
        esc = achado.get("corners")
        out[f"escanteios_{lado}"] = esc[i][0] if esc else np.nan
        cr = achado.get("accurate_crosses")
        if cr and cr[i][1]:
            out[f"cruz_{lado}"] = cr[i][0] / cr[i][1]
        else:
            out[f"cruz_{lado}"] = cr[i][0] if cr else np.nan
        ae = achado.get("aerials_won")
        out[f"aereo_pct_{lado}"] = ae[i][1] if ae and ae[i][1] is not None else np.nan
        for chave, nome in (("big_chance", "grandes"), ("big_chance_missed_title", "grandes_perdidas"),
                            ("shots_inside_box", "chutes_area")):
            v = achado.get(chave)
            out[f"{nome}_{lado}"] = v[i][0] if v else np.nan
    return out


def historico_times(jogos):
    # Média móvel exponencial dos jogos ANTERIORES de cada time (shift de 1 jogo)
    lados = pd.concat([
        jogos.assign(time=jogos.casa, gf=jogos.gols_casa, gs=jogos.gols_fora, cf=jogos.chutes_casa, cs=jogos.chutes_fora,
                     hf=jogos.cab_casa, hs=jogos.cab_fora, ef=jogos.escanteios_casa, es=jogos.escanteios_fora,
                     xf=jogos.cruz_casa, xs=jogos.cruz_fora, ap=jogos.aereo_pct_casa),
        jogos.assign(time=jogos.fora, gf=jogos.gols_fora, gs=jogos.gols_casa, cf=jogos.chutes_fora, cs=jogos.chutes_casa,
                     hf=jogos.cab_fora, hs=jogos.cab_casa, ef=jogos.escanteios_fora, es=jogos.escanteios_casa,
                     xf=jogos.cruz_fora, xs=jogos.cruz_casa, ap=jogos.aereo_pct_fora),
    ]).sort_values("data")
    # hf/hs cabeçadas a favor/contra, ef/es escanteios, xf/xs cruzamentos, ap % de duelos aéreos ganhos
    COLS = ("gf", "gs", "cf", "cs", "hf", "hs", "ef", "es", "xf", "xs", "ap")
    for col in COLS:
        lados[f"{col}_ant"] = lados.groupby("time")[col].transform(
            lambda s: s.ewm(halflife=MEIA_VIDA_TIME, ignore_na=True).mean().shift(1))
        # time sem histórico (estreante no dataset) fica com a média da liga
        lados[f"{col}_ant"] = lados[f"{col}_ant"].fillna(lados[col].mean())
    return lados[["f_arq", "time"] + [f"{col}_ant" for col in COLS]]


def historico_jogador(c):
    # Chutes e gols anteriores do jogador (sem pênalti), puxados para a média da liga
    c = c.sort_values(["data", "f_id"])
    sp = c.lance != "Penalty"
    c["_ch"] = sp.astype(int)
    c["_gl"] = (sp & (c.gol == 1)).astype(int)
    c["_hc"] = (c.parte == "Header").astype(int)
    c["_hg"] = ((c.parte == "Header") & (c.gol == 1)).astype(int)
    # só jogos ANTERIORES: acumulado até o jogo anterior (exclui o próprio jogo inteiro)
    por_jogo = c.groupby(["jogador", "f_arq"], sort=False).agg(data=("data", "first"), ch=("_ch", "sum"), gl=("_gl", "sum"),
                                                              hc=("_hc", "sum"), hg=("_hg", "sum"))
    por_jogo = por_jogo.reset_index().sort_values("data")
    g = por_jogo.groupby("jogador")
    por_jogo["ch_ant"] = g.ch.cumsum() - por_jogo.ch
    por_jogo["gl_ant"] = g.gl.cumsum() - por_jogo.gl
    por_jogo["hc_ant"] = g.hc.cumsum() - por_jogo.hc
    por_jogo["hg_ant"] = g.hg.cumsum() - por_jogo.hg
    c = c.merge(por_jogo[["jogador", "f_arq", "ch_ant", "gl_ant", "hc_ant", "hg_ant"]], on=["jogador", "f_arq"])
    sp = c.lance != "Penalty"   # recalculado: o merge refez o índice
    taxa_liga = c.loc[sp].groupby("liga").gol.mean()
    r0 = c.liga.map(taxa_liga)
    c["conv_jogador"] = (c.gl_ant + K_JOGADOR * r0) / (c.ch_ant + K_JOGADOR)
    # cabeçadas: parcela das finalizações do jogador e conversão de cabeça, puxadas para a média
    cab = c.parte == "Header"
    h0 = c.liga.map(c.loc[cab].groupby("liga").gol.mean())
    c["cab_parcela_jogador"] = (c.hc_ant + K_JOGADOR * c.liga.map(cab.groupby(c.liga).mean())) / (c.ch_ant + K_JOGADOR)
    c["cab_conv_jogador"] = (c.hg_ant + K_JOGADOR * h0) / (c.hc_ant + K_JOGADOR)
    return c.drop(columns=["_ch", "_gl", "_hc", "_hg"])


def main():
    todos = []
    for pasta, liga in LIGAS.items():
        chutes, jogos, jogadores = [], [], []
        for ano in TEMPORADAS:
            for arq in glob.glob(f"data/bruto/fotmob/{pasta}/{ano}/*.json.gz"):
                if arq.endswith("liga.json.gz"):
                    continue
                ch, jg, jd = chutes_do_jogo(arq, liga, ano)
                chutes += ch
                jogos.append(jg)
                jogadores += jd
        c, j = pd.DataFrame(chutes), pd.DataFrame(jogos)
        h = historico_times(j)
        # estatísticas do próprio jogo, do lado de quem chuta (jg_) e do adversário (jga_)
        lados = pd.concat([
            j.assign(time=j.casa, **{f"jg_{n}": j[f"{n}_casa"] for n in ("grandes", "grandes_perdidas", "chutes_area", "cruz", "escanteios")},
                     **{f"jga_{n}": j[f"{n}_fora"] for n in ("grandes", "chutes_area")}),
            j.assign(time=j.fora, **{f"jg_{n}": j[f"{n}_fora"] for n in ("grandes", "grandes_perdidas", "chutes_area", "cruz", "escanteios")},
                     **{f"jga_{n}": j[f"{n}_casa"] for n in ("grandes", "chutes_area")}),
        ])
        c = c.merge(lados[["f_arq", "time"] + [x for x in lados.columns if x.startswith("jg")]], on=["f_arq", "time"])
        # escalação: ataque de quem chuta e defesa/goleiro de quem defende
        esc = forca_escalacao(pd.DataFrame(jogadores))
        atq = esc[["f_arq", "time", "esc_atq_gols_90", "esc_atq_chutes_90", "esc_atq_gc_perdidas_90",
                   "esc_atq_criadas_90", "esc_rodizio"]].rename(columns={"esc_rodizio": "esc_atq_rodizio"})
        dfn = esc[["f_arq", "time", "esc_def_aereos_90", "esc_def_acoes_def_90", "esc_def_driblado_90",
                   "esc_def_erros_90", "esc_gk_defesa_pct", "esc_rodizio"]].rename(
                       columns={"time": "adversario", "esc_rodizio": "esc_def_rodizio"})
        c = c.merge(atq, on=["f_arq", "time"], how="left").merge(dfn, on=["f_arq", "adversario"], how="left")
        c = c.merge(h.add_prefix("atq_").rename(columns={"atq_f_arq": "f_arq", "atq_time": "time"}), on=["f_arq", "time"])
        c = c.merge(h.add_prefix("def_").rename(columns={"def_f_arq": "f_arq", "def_time": "adversario"}), on=["f_arq", "adversario"])
        todos.append(c)
    c = historico_jogador(pd.concat(todos, ignore_index=True))
    # lugar: distância ao centro do gol e ângulo de visão entre as traves (7,32 m)
    dx, dy = 105 - c.x, c.y - 34
    c["distancia"] = np.hypot(dx, dy)
    c["angulo"] = np.degrees(np.abs(np.arctan2(7.32 * dx, dx**2 + dy**2 - (7.32 / 2) ** 2)))
    # alvo: xG da Understat do chute pareado
    p = pd.read_pickle("modelo_xg/dados/chutes_pareados.pkl")[["f_arq", "f_id", "u_xG", "u_match", "h_a"]]
    c = c.merge(p.rename(columns={"u_xG": "xg_understat"}), on=["f_arq", "f_id"], how="left")
    c["xg_understat"] = c.xg_understat.astype(float)
    os.makedirs(os.path.dirname(SAIDA), exist_ok=True)
    c.to_pickle(SAIDA)
    print(f"{len(c)} chutes; com alvo: {c.xg_understat.notna().mean():.1%}")
    print(c.groupby(["liga", "season"]).size().unstack())


if __name__ == "__main__":
    main()
