"""Força da escalação de cada time em cada jogo, jogador por jogador, só com o passado.

Para cada jogador em cada jogo, lê as estatísticas do FotMob (minutos, gols, chutes,
grandes chances perdidas, chances criadas, duelos aéreos, ações defensivas, dribles
sofridos, erros que viraram gol, defesas e gols sofridos do goleiro). O histórico de
cada jogador soma só os jogos ANTERIORES e vira taxa por 90 minutos, puxada para a
média da posição quando ele tem poucos minutos (a nota do FotMob fica fora: é
opinião de outro modelo).

Depois, para os 11 titulares de cada time no jogo:
  ataque   atacantes e meias: gols, chutes, grandes chances perdidas e chances
           criadas por 90 minutos
  defesa   zagueiros e laterais: duelos aéreos, ações defensivas, dribles sofridos e
           erros por 90 minutos
  goleiro  % de defesas (defesas / (defesas + gols sofridos)), puxada para a média
  rodízio  minutos anteriores dos titulares na temporada, em relação ao time
           (escalação reserva ou com desfalques fica mais baixa)
"""
import gzip
import json
import os

import numpy as np
import pandas as pd

MINUTOS_PRIOR = 900     # minutos "fictícios" na média da posição
CHAVES = {"minutes_played": "min", "goals": "gols", "total_shots": "chutes",
          "big_chance_missed_title": "gc_perdidas", "chances_created": "criadas",
          "aerials_won": "aereos", "defensive_actions": "acoes_def", "dribbled_past": "driblado",
          "errors_led_to_goal": "erros", "saves": "defesas", "goals_conceded": "gols_sofridos"}
TAXAS = ["gols", "chutes", "gc_perdidas", "criadas", "aereos", "acoes_def", "driblado", "erros"]


def jogadores_do_jogo(d, arq, data, season):
    # Uma linha por jogador que entrou em campo, com titular/reserva e posição usual
    c = d["content"]
    titulares = set()
    for lado in ("homeTeam", "awayTeam"):
        titulares |= {s["id"] for s in (c.get("lineup") or {}).get(lado, {}).get("starters") or []}
    linhas = []
    for p in (c.get("playerStats") or {}).values():
        l = dict(f_arq=os.path.basename(arq), data=data, season=season, jogador=p["id"], time=p["teamId"],
                 posicao=p.get("usualPosition"), titular=int(p["id"] in titulares))
        for grp in p.get("stats") or []:
            for v in (grp.get("stats") or {}).values():
                if v.get("key") in CHAVES:
                    val = (v.get("stat") or {}).get("value")
                    l[CHAVES[v["key"]]] = float(val) if isinstance(val, (int, float)) else 0.0
        linhas.append(l)
    return linhas


def forca_escalacao(jog):
    # Histórico ANTERIOR de cada jogador e agregação pelos titulares de cada time no jogo
    jog = jog.copy()
    for col in CHAVES.values():
        if col not in jog:
            jog[col] = 0.0
        jog[col] = jog[col].fillna(0.0)
    jog = jog.sort_values("data")
    g = jog.groupby("jogador")
    for col in CHAVES.values():
        jog[f"{col}_ant"] = g[col].cumsum() - jog[col]
    # minutos anteriores na mesma temporada (rodízio)
    jog["min_temp_ant"] = jog.groupby(["jogador", "season"])["min"].cumsum() - jog["min"]
    # taxa por 90 minutos puxada para a média da posição
    for col in TAXAS:
        media = (jog.groupby("posicao")[col].sum() / jog.groupby("posicao")["min"].sum()).rename("m")
        m = jog.posicao.map(media).fillna(0)
        jog[f"{col}_90"] = 90 * (jog[f"{col}_ant"] + MINUTOS_PRIOR * m) / (jog["min_ant"] + MINUTOS_PRIOR)
    gk = jog.posicao == 0
    media_def = jog.loc[gk, "defesas"].sum() / (jog.loc[gk, "defesas"].sum() + jog.loc[gk, "gols_sofridos"].sum())
    jog["gk_defesa_pct"] = (jog.defesas_ant + 30 * media_def) / (jog.defesas_ant + jog.gols_sofridos_ant + 30)

    tit = jog[jog.titular == 1]
    atq = tit[tit.posicao.isin([2, 3])].groupby(["f_arq", "time"])[
        ["gols_90", "chutes_90", "gc_perdidas_90", "criadas_90"]].mean().add_prefix("esc_atq_")
    dfn = tit[tit.posicao == 1].groupby(["f_arq", "time"])[
        ["aereos_90", "acoes_def_90", "driblado_90", "erros_90"]].mean().add_prefix("esc_def_")
    gol = tit[tit.posicao == 0].groupby(["f_arq", "time"])[["gk_defesa_pct"]].mean().add_prefix("esc_")
    rod = tit.groupby(["f_arq", "time", "season"]).min_temp_ant.sum().rename("esc_min_titulares").reset_index()
    # rodízio: minutos dos titulares em relação ao maior valor do time na temporada até ali
    rod["esc_rodizio"] = rod.esc_min_titulares / rod.groupby(["time", "season"]).esc_min_titulares.cummax().replace(0, np.nan)
    rod = rod.set_index(["f_arq", "time"])[["esc_rodizio"]]
    return atq.join(dfn, how="outer").join(gol, how="outer").join(rod, how="outer").reset_index()


def ler(caminho):
    with gzip.open(caminho) as f:
        return json.load(f)
